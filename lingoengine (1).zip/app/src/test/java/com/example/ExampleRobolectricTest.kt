package com.example

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.test.core.app.ApplicationProvider
import com.example.model.MainNavTab
import com.example.ui.LingoViewModel
import com.example.ui.components.GoogleAccountInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Yazen lingo Engine", appName)
  }

  @Test
  fun `test tab switching between LEARN and PROFILE`() {
    val viewModel = LingoViewModel()
    assertEquals(MainNavTab.LEARN, viewModel.uiState.value.currentTab)

    viewModel.selectTab(MainNavTab.PROFILE)
    assertEquals(MainNavTab.PROFILE, viewModel.uiState.value.currentTab)

    viewModel.selectTab(MainNavTab.LEARN)
    assertEquals(MainNavTab.LEARN, viewModel.uiState.value.currentTab)
  }

  @Test
  fun `test google sign in and sign out flow`() {
    val viewModel = LingoViewModel()
    assertFalse(viewModel.uiState.value.isGoogleSignedIn)

    val account = GoogleAccountInfo(
      email = "yazen.learner@gmail.com",
      displayName = "يزن محمد",
      avatarBgColor = Color(0xFF4285F4)
    )
    viewModel.signInWithGoogleAccount(account)

    assertTrue(viewModel.uiState.value.isGoogleSignedIn)
    assertEquals("yazen.learner@gmail.com", viewModel.uiState.value.userGoogleEmail)
    assertEquals("يزن محمد", viewModel.uiState.value.userGoogleName)

    viewModel.signOutGoogle()
    assertFalse(viewModel.uiState.value.isGoogleSignedIn)
  }

  @Test
  fun `test refill hearts updates balance to five`() {
    val viewModel = LingoViewModel()
    viewModel.refillHearts()
    assertEquals(5, viewModel.uiState.value.pointsBalance.heartsRemaining)
  }
}
