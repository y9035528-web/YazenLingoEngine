package com.example.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Audio and Haptic feedback helper matching authentic Duolingo sound style:
 * - Joyful major chime arpeggio on correct answer (Ding)
 * - Gentle descending low dual-tone alert on wrong answer (Fail tone)
 * - Snappy woodblock/bubble pop on word chip tap (Pop)
 * - Text-To-Speech with normal and slow (turtle) speech rates
 */
class AudioFeedbackHelper(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private val audioExecutor = Executors.newSingleThreadExecutor()

    // Pre-synthesized PCM 16-bit audio buffers for instant 0ms playback
    private val successPcm: ByteArray by lazy { generateDuolingoSuccessChime() }
    private val failurePcm: ByteArray by lazy { generateDuolingoFailureTone() }
    private val popPcm: ByteArray by lazy { generateDuolingoWordPop() }

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
                tts?.language = Locale.ENGLISH
            }
        }
    }

    /**
     * Pronounces text with TTS. Supports slow speed (0.6x) for listening exercises (Duolingo turtle mode).
     */
    fun speak(text: String, languageCode: String, isSlow: Boolean = false) {
        if (!isTtsReady || tts == null) return

        val locale = when (languageCode.lowercase()) {
            "es", "spanish" -> Locale("es", "ES")
            "fr", "french" -> Locale.FRENCH
            "de", "german" -> Locale.GERMAN
            else -> Locale.ENGLISH
        }

        try {
            tts?.language = locale
            tts?.setSpeechRate(if (isSlow) 0.6f else 1.0f)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lingo_speech_id_${System.currentTimeMillis()}")
        } catch (_: Exception) {
            // Graceful fallback
        }
    }

    /**
     * Joyful Duolingo-style success chime: ascending 4-note major arpeggio with bell resonance.
     */
    fun playSuccessFeedback() {
        playPcmBuffer(successPcm)
        vibrate(shortSuccess = true)
    }

    /**
     * Gentle Duolingo-style low double-thud alert on incorrect answers.
     */
    fun playFailureFeedback() {
        playPcmBuffer(failurePcm)
        vibrate(shortSuccess = false)
    }

    /**
     * Fast, snappy bubble-pop sound when tapping word chips or selecting options.
     */
    fun playWordTapClick() {
        playPcmBuffer(popPcm)
        performLightHaptic()
    }

    /**
     * Plays a pre-generated PCM 16-bit mono 44.1kHz buffer through AudioTrack.
     */
    private fun playPcmBuffer(pcmData: ByteArray) {
        audioExecutor.execute {
            try {
                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(44100)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(pcmData.size)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(pcmData, 0, pcmData.size)
                audioTrack.play()

                // Release track after playback completes
                val durationMs = (pcmData.size / 2.0 / 44100.0 * 1000.0).toLong() + 50L
                Thread.sleep(durationMs)
                audioTrack.stop()
                audioTrack.release()
            } catch (_: Exception) {
                // Ignore audio hardware transient exceptions
            }
        }
    }

    private fun performLightHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                    vm?.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                }
                vibrator?.vibrate(VibrationEffect.createOneShot(15, 120))
            }
        } catch (_: Exception) {}
    }

    private fun vibrate(shortSuccess: Boolean) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            } ?: return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (shortSuccess) {
                    vibrator.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    val timings = longArrayOf(0, 70, 50, 90)
                    val amplitudes = intArrayOf(0, 160, 0, 200)
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                }
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(if (shortSuccess) 45L else 160L)
            }
        } catch (_: Exception) {}
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            audioExecutor.shutdown()
        } catch (_: Exception) {}
    }

    companion object {
        private const val SAMPLE_RATE = 44100

        /**
         * Synthesizes Duolingo's signature ascending major arpeggio chime (D5 -> F#5 -> A5 -> D6).
         */
        private fun generateDuolingoSuccessChime(): ByteArray {
            val durationSeconds = 0.52
            val totalSamples = (SAMPLE_RATE * durationSeconds).toInt()
            val byteBuffer = ByteArray(totalSamples * 2)

            val notes = listOf(
                Pair(587.33, 0.08),  // D5
                Pair(739.99, 0.08),  // F#5
                Pair(880.00, 0.08),  // A5
                Pair(1174.66, 0.28)  // D6 with bell ring
            )

            var sampleIndex = 0
            for ((freq, noteDuration) in notes) {
                val noteSamples = (SAMPLE_RATE * noteDuration).toInt()
                for (i in 0 until noteSamples) {
                    if (sampleIndex >= totalSamples) break
                    val t = i.toDouble() / SAMPLE_RATE
                    val progress = i.toDouble() / noteSamples

                    // Smooth attack and ringing decay envelope
                    val envelope = when {
                        progress < 0.08 -> progress / 0.08
                        else -> exp(-progress * 3.8)
                    }

                    // Bell harmonic mixture (fundamental + warm 2nd harmonic)
                    val wave = (sin(2.0 * PI * freq * t) * 0.75) +
                            (sin(4.0 * PI * freq * t) * 0.25)
                    val sampleVal = (wave * envelope * 0.65 * Short.MAX_VALUE).toInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())

                    byteBuffer[sampleIndex * 2] = (sampleVal and 0xFF).toByte()
                    byteBuffer[sampleIndex * 2 + 1] = ((sampleVal shr 8) and 0xFF).toByte()
                    sampleIndex++
                }
            }

            return byteBuffer
        }

        /**
         * Synthesizes Duolingo's soft low double-thud on wrong answers.
         */
        private fun generateDuolingoFailureTone(): ByteArray {
            val durationSeconds = 0.38
            val totalSamples = (SAMPLE_RATE * durationSeconds).toInt()
            val byteBuffer = ByteArray(totalSamples * 2)

            // Segment 1: Low 170Hz thud (0 to 110ms)
            val seg1Samples = (SAMPLE_RATE * 0.11).toInt()
            for (i in 0 until seg1Samples) {
                val t = i.toDouble() / SAMPLE_RATE
                val progress = i.toDouble() / seg1Samples
                val envelope = if (progress < 0.1) progress / 0.1 else exp(-progress * 4.0)
                val wave = sin(2.0 * PI * 170.0 * t) + (0.3 * sin(2.0 * PI * 85.0 * t))
                val sampleVal = (wave * envelope * 0.55 * Short.MAX_VALUE).toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())

                byteBuffer[i * 2] = (sampleVal and 0xFF).toByte()
                byteBuffer[i * 2 + 1] = ((sampleVal shr 8) and 0xFF).toByte()
            }

            // Segment 2: Brief pause (110ms to 140ms) - already 0s in byteBuffer

            // Segment 3: Descending low buzz 135Hz -> 90Hz (140ms to 380ms)
            val seg3Start = (SAMPLE_RATE * 0.14).toInt()
            val seg3Samples = totalSamples - seg3Start
            for (i in 0 until seg3Samples) {
                val sampleIdx = seg3Start + i
                if (sampleIdx >= totalSamples) break
                val t = i.toDouble() / SAMPLE_RATE
                val progress = i.toDouble() / seg3Samples
                val currentFreq = 135.0 - (45.0 * progress)
                val envelope = if (progress < 0.08) progress / 0.08 else exp(-progress * 3.5)
                val wave = sin(2.0 * PI * currentFreq * t) + (0.25 * sin(2.0 * PI * (currentFreq / 2) * t))
                val sampleVal = (wave * envelope * 0.55 * Short.MAX_VALUE).toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())

                byteBuffer[sampleIdx * 2] = (sampleVal and 0xFF).toByte()
                byteBuffer[sampleIdx * 2 + 1] = ((sampleVal shr 8) and 0xFF).toByte()
            }

            return byteBuffer
        }

        /**
         * Synthesizes Duolingo's snappy bubble-pop sound when clicking word blocks.
         */
        private fun generateDuolingoWordPop(): ByteArray {
            val durationSeconds = 0.038 // 38ms crisp pop
            val totalSamples = (SAMPLE_RATE * durationSeconds).toInt()
            val byteBuffer = ByteArray(totalSamples * 2)

            var phase = 0.0
            for (i in 0 until totalSamples) {
                val progress = i.toDouble() / totalSamples
                // Pitch sweeps rapidly from 1250 Hz down to 420 Hz
                val instantFreq = 420.0 + 830.0 * exp(-progress * 6.5)
                phase += 2.0 * PI * instantFreq / SAMPLE_RATE

                // Fast attack, quick exponential falloff
                val envelope = if (progress < 0.08) {
                    progress / 0.08
                } else {
                    exp(-progress * 7.0)
                }

                val wave = sin(phase)
                val sampleVal = (wave * envelope * 0.70 * Short.MAX_VALUE).toInt()
                    .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())

                byteBuffer[i * 2] = (sampleVal and 0xFF).toByte()
                byteBuffer[i * 2 + 1] = ((sampleVal shr 8) and 0xFF).toByte()
            }

            return byteBuffer
        }
    }
}

