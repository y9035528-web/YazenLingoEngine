package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = LingoGreen,
    onPrimary = Color.White,
    primaryContainer = LingoGreenDark,
    onPrimaryContainer = LingoGreenLight,
    secondary = LingoBlue,
    onSecondary = Color.White,
    secondaryContainer = LingoBlueDark,
    onSecondaryContainer = LingoBlueLight,
    tertiary = LingoYellow,
    error = LingoRed,
    background = LingoDarkBackground,
    surface = LingoDarkSurface,
    surfaceVariant = LingoDarkSurfaceVariant,
    onBackground = LingoDarkTextPrimary,
    onSurface = LingoDarkTextPrimary,
    outline = LingoDarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = LingoGreen,
    onPrimary = Color.White,
    primaryContainer = LingoGreenSubtle,
    onPrimaryContainer = LingoGreenDark,
    secondary = LingoBlue,
    onSecondary = Color.White,
    secondaryContainer = LingoBlueLight,
    onSecondaryContainer = LingoBlueDark,
    tertiary = LingoYellow,
    error = LingoRed,
    background = LingoGrayBackground,
    surface = Color.White,
    surfaceVariant = Color(0xFFF1F5F9),
    onBackground = LingoTextPrimary,
    onSurface = LingoTextPrimary,
    outline = LingoCardBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
