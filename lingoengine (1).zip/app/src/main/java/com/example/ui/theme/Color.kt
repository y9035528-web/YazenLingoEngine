package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Duolingo Inspired Vibrant Palette
val LingoGreen = Color(0xFF58CC02)
val LingoGreenDark = Color(0xFF58A700)
val LingoGreenLight = Color(0xFFD7FFB8)
val LingoGreenSubtle = Color(0xFFEAF9DC)
val LingoNeonGreen = Color(0xFF26FF4E) // Phosphorescent bright neon green for ripple
val LingoWordButtonBg = Color(0xFF2B3A42) // Rich dark slate background for maximum contrast with #FFFFFF
val LingoWordButtonBgPressed = Color(0xFF1E2C33)
val LingoWordButtonBorder = Color(0xFF475569)

val LingoBlue = Color(0xFF1CB0F6)
val LingoBlueDark = Color(0xFF1899D6)
val LingoBlueLight = Color(0xFFDDF4FF)

val LingoRed = Color(0xFFFF4B4B)
val LingoRedDark = Color(0xFFEA2B2B)
val LingoRedLight = Color(0xFFFFDFE0)
val LingoRedSubtle = Color(0xFFFDE8E8)

val LingoYellow = Color(0xFFFFC800)
val LingoYellowDark = Color(0xFFE5A500)
val LingoYellowLight = Color(0xFFFFF5D6)

val LingoOrange = Color(0xFFFF9600)
val LingoOrangeDark = Color(0xFFCC7800)

val LingoPurple = Color(0xFFCE82FF)
val LingoPurpleDark = Color(0xFFA545EE)

val LingoLockedGray = Color(0xFFE5E5E5)
val LingoLockedGrayDark = Color(0xFFAFAFAF)
val LingoLockedText = Color(0xFF8E8E93)


// Neutrals
val LingoGrayBackground = Color(0xFFF7F9FA)
val LingoCardBorder = Color(0xFFE5E7EB)
val LingoTextPrimary = Color(0xFF1F2937)
val LingoTextSecondary = Color(0xFF6B7280)
val LingoSlotPlaceholder = Color(0xFFE2E8F0)

// Dark Mode Palette
val LingoDarkBackground = Color(0xFF131F24)
val LingoDarkSurface = Color(0xFF1A2C33)
val LingoDarkSurfaceVariant = Color(0xFF223842)
val LingoDarkTextPrimary = Color(0xFFF3F4F6)
val LingoDarkTextSecondary = Color(0xFF9CA3AF)
val LingoDarkBorder = Color(0xFF2B4552)
