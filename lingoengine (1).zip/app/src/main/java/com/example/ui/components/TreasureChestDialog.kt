package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LessonNode
import com.example.model.LessonNodeStatus
import com.example.ui.theme.LingoGreen
import com.example.ui.theme.LingoGreenDark
import com.example.ui.theme.LingoYellow
import com.example.ui.theme.LingoYellowDark
import com.example.ui.theme.NunitoFontFamily
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TreasureChestDialog(
    chestNode: LessonNode,
    unitCompletedCount: Int, // Number of completed stages out of 10
    totalStagesInUnit: Int = 10,
    onClaimReward: (unitNumber: Int) -> Unit,
    onDismiss: () -> Unit
) {
    val isReadyToOpen = (unitCompletedCount >= totalStagesInUnit) && !chestNode.isChestClaimed
    val isAlreadyClaimed = chestNode.isChestClaimed

    var isChestOpened by remember { mutableStateOf(false) }

    // Auto-open chest animation after short delay if ready
    LaunchedEffect(isReadyToOpen) {
        if (isReadyToOpen) {
            delay(400)
            isChestOpened = true
        }
    }

    // Infinite rotation for rays/glow behind chest
    val infiniteTransition = rememberInfiniteTransition(label = "chest_glow_anim")
    val glowRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 10000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "glow_rotation"
    )

    val chestScale by animateFloatAsState(
        targetValue = if (isChestOpened) 1.15f else 1.0f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 300f),
        label = "chest_scale"
    )

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("treasure_chest_dialog")
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = Color(0xFF0F172A), // High contrast dark slate
            border = androidx.compose.foundation.BorderStroke(
                2.dp,
                if (isReadyToOpen) LingoYellow else Color(0xFF334155)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Close Button Top Right
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF94A3B8)
                        )
                    }
                }

                // Visual Chest Showcase with Glowing Backdrop
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(140.dp)
                        .padding(8.dp)
                ) {
                    if (isReadyToOpen) {
                        // Radiant Rotating Glow
                        Box(
                            modifier = Modifier
                                .size(130.dp)
                                .rotate(glowRotation)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(
                                            Color(0xFFFFD700).copy(alpha = 0.45f),
                                            Color(0xFFF59E0B).copy(alpha = 0.2f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                    }

                    // Chest Emoji / Icon
                    Text(
                        text = when {
                            isAlreadyClaimed -> "🏆"
                            isChestOpened -> "🎉"
                            isReadyToOpen -> "🎁"
                            else -> "🔒"
                        },
                        fontSize = if (isChestOpened) 72.sp else 64.sp,
                        modifier = Modifier.scale(chestScale)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Title and Subtitle based on state
                when {
                    isAlreadyClaimed -> {
                        Text(
                            text = "تم استلام كنز الوحدة ${chestNode.unitNumber} بنجاح!",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "لقد حصلت بالفعل على 100 XP والمجوهرات لهذا المستوى وفتحت المراحل التالية.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Duolingo3DButton(
                            onClick = onDismiss,
                            topColor = Color(0xFF334155),
                            shadowColor = Color(0xFF1E293B),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Text("إغلاق", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    isReadyToOpen -> {
                        Text(
                            text = "مبروك! فتحت صندوق كنز الوحدة ${chestNode.unitNumber} 👑",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "أكملت جميع مراحل الوحدة الـ 10 بجدارة! استلم مكافأتك الملكية وافتح المستوى التالي مباشرة:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFCBD5E1),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Rewards Cards Row (XP + Gems)
                        AnimatedVisibility(
                            visible = isChestOpened,
                            enter = fadeIn() + scaleIn()
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // XP Card
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color(0xFF1E293B),
                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, LingoYellow),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(text = "⭐", fontSize = 28.sp)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "+100 XP",
                                            fontFamily = NunitoFontFamily,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = LingoYellow
                                        )
                                        Text(
                                            text = "نقاط خبرة",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF94A3B8)
                                        )
                                    }
                                }

                                // Gems Card
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color(0xFF1E293B),
                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF38BDF8)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(text = "💎", fontSize = 28.sp)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "+25",
                                            fontFamily = NunitoFontFamily,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFF38BDF8)
                                        )
                                        Text(
                                            text = "مجوهرات نادرة",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF94A3B8)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(22.dp))

                        // Claim Button
                        Duolingo3DButton(
                            onClick = {
                                onClaimReward(chestNode.unitNumber)
                            },
                            topColor = LingoGreen,
                            shadowColor = LingoGreenDark,
                            bevelDepth = 5.dp,
                            testTag = "claim_treasure_chest_button",
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "استلم المكافأة وافتح المستوى التالي 🚀",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    else -> {
                        // Locked Chest State
                        Text(
                            text = "صندوق الكنز مقفل 🔒",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "لفتح هذا الصندوق الذهبي، يجب عليك إكمال جميع المراحل العشر في هذه الوحدة بنظام القفل المتسلسل.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Progress Indicator
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color(0xFF1E293B),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "المراحل المكتملة:",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color(0xFFCBD5E1)
                                    )
                                    Text(
                                        text = "$unitCompletedCount / $totalStagesInUnit",
                                        fontFamily = NunitoFontFamily,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = LingoYellow
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                androidx.compose.material3.LinearProgressIndicator(
                                    progress = { unitCompletedCount.toFloat() / totalStagesInUnit.toFloat() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(5.dp)),
                                    color = LingoGreen,
                                    trackColor = Color(0xFF334155)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Duolingo3DButton(
                            onClick = onDismiss,
                            topColor = Color(0xFF2563EB),
                            shadowColor = Color(0xFF1D4ED8),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Text(
                                text = "حسناً، سأكمل المراحل الآن 🎯",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
