package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PointsBalance
import com.example.ui.theme.LingoBlue
import com.example.ui.theme.LingoCardBorder
import com.example.ui.theme.LingoGreen
import com.example.ui.theme.LingoOrange
import com.example.ui.theme.LingoRed
import com.example.ui.theme.LingoYellow

@Composable
fun LingoTopBar(
    progress: Float,
    pointsBalance: PointsBalance,
    courseTitle: String,
    courseFlag: String,
    onLanguageClick: () -> Unit,
    onOpenJsonInspector: () -> Unit,
    showProgressBar: Boolean = true,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 400),
        label = "progress_anim"
    )

    Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            // Brand & App Title Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "🦉",
                        fontSize = 20.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Yazen lingo Engine",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.testTag("app_title_header")
                    )
                }

                // JSON Inspector quick action
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(LingoBlue.copy(alpha = 0.15f))
                        .clickable { onOpenJsonInspector() }
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("json_inspector_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = "عرض مخرجات JSON",
                            tint = LingoBlue,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "JSON",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = LingoBlue
                        )
                    }
                }
            }

            // Row 1: Language chip + Stats badges (Streak, XP, Hearts)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Language selector pill
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(1.dp, LingoCardBorder, RoundedCornerShape(20.dp))
                        .clickable { onLanguageClick() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("language_selector_chip"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = courseFlag,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = courseTitle,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.Translate,
                        contentDescription = "Switch Language",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Stats row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Streak Badge with flame
                    StatBadge(
                        icon = {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Streak",
                                tint = LingoOrange,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        value = "${pointsBalance.streakDays}",
                        color = LingoOrange,
                        testTag = "streak_badge"
                    )

                    // XP Badge
                    StatBadge(
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "XP",
                                tint = LingoYellow,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        value = "${pointsBalance.totalXp}",
                        color = Color(0xFFD97706),
                        testTag = "xp_badge"
                    )

                    // Gems Badge (💎)
                    StatBadge(
                        icon = {
                            Text(text = "💎", fontSize = 16.sp)
                        },
                        value = "${pointsBalance.gems}",
                        color = Color(0xFF0284C7),
                        testTag = "gems_badge"
                    )

                    // Hearts Badge (e.g. 5 or 5/5)
                    StatBadge(
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "Hearts",
                                tint = LingoRed,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        value = "${pointsBalance.heartsRemaining}",
                        color = LingoRed,
                        testTag = "hearts_badge"
                    )
                }
            }

            if (showProgressBar) {
                Spacer(modifier = Modifier.height(10.dp))

                // Row 2: Smooth Progress Bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .testTag("lesson_progress_bar"),
                        color = LingoGreen,
                        trackColor = Color.Transparent
                    )
                }
            }
        }
    }
}


@Composable
private fun StatBadge(
    icon: @Composable () -> Unit,
    value: String,
    color: Color,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .testTag(testTag)
            .padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon()
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.ExtraBold,
            color = color
        )
    }
}
