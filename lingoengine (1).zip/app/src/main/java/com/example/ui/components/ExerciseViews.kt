package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ripple
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExerciseItem
import com.example.model.QuestionType
import com.example.model.StepSubmissionState
import com.example.ui.theme.LingoBlue
import com.example.ui.theme.LingoBlueDark
import com.example.ui.theme.LingoBlueLight
import com.example.ui.theme.LingoCardBorder
import com.example.ui.theme.LingoGreen
import com.example.ui.theme.LingoGreenDark
import com.example.ui.theme.LingoGreenLight
import com.example.ui.theme.LingoGreenSubtle
import com.example.ui.theme.LingoNeonGreen
import com.example.ui.theme.LingoRed
import com.example.ui.theme.LingoRedSubtle
import com.example.ui.theme.LingoSlotPlaceholder
import com.example.ui.theme.LingoWordButtonBg
import com.example.ui.theme.LingoWordButtonBgPressed
import com.example.ui.theme.LingoWordButtonBorder

@Composable
fun ExercisePromptHeader(
    exercise: ExerciseItem,
    onPlayAudio: () -> Unit,
    onPlaySlowAudio: (() -> Unit)? = null,
    isEvaluated: Boolean = false,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Arabic instruction: High contrast ExtraBold display
        Text(
            text = exercise.instruction,
            style = MaterialTheme.typography.headlineSmall.copy(
                fontSize = 26.sp,
                lineHeight = 34.sp
            ),
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("exercise_instruction")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Mascot and Speech Bubble container
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Owl mascot avatar
            MascotAvatar(
                modifier = Modifier.size(56.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Speech Bubble with target sentence or listening audio controller
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 3.dp,
                modifier = Modifier
                    .weight(1f)
                    .border(2.dp, LingoCardBorder, RoundedCornerShape(18.dp))
                    .testTag("target_speech_bubble")
            ) {
                if (exercise.type == QuestionType.LISTEN_SELECT && !isEvaluated) {
                    // Authentic Duolingo Listening Card
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Normal Speed Speaker
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(LingoBlue)
                                .clickable { onPlayAudio() }
                                .testTag("tts_play_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "استمع للنطق العادي",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        // Slow Turtle Speed Button
                        if (onPlaySlowAudio != null) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0284C7).copy(alpha = 0.2f))
                                    .border(1.dp, Color(0xFF38BDF8), CircleShape)
                                    .clickable { onPlaySlowAudio() }
                                    .testTag("tts_play_slow_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "🐢",
                                    fontSize = 18.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🎧 استمع بدقة للصوت",
                                style = MaterialTheme.typography.titleMedium.copy(fontSize = 17.sp),
                                fontWeight = FontWeight.ExtraBold,
                                color = LingoBlue,
                                modifier = Modifier.testTag("listening_mode_hint")
                            )
                            Text(
                                text = "اضغط على زر الصوت للاستماع",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Audio pronunciation button
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(LingoBlue.copy(alpha = 0.15f))
                                .clickable { onPlayAudio() }
                                .testTag("tts_play_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "استمع للنطق",
                                tint = LingoBlue,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        if (onPlaySlowAudio != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF0284C7).copy(alpha = 0.15f))
                                    .clickable { onPlaySlowAudio() }
                                    .testTag("tts_play_slow_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "🐢",
                                    fontSize = 16.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = exercise.targetText,
                                style = MaterialTheme.typography.titleLarge.copy(fontSize = 22.sp),
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag("target_text_display")
                            )

                            if (exercise.phonetic.isNotBlank()) {
                                Text(
                                    text = "/${exercise.phonetic}/",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontStyle = FontStyle.Italic,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MascotAvatar(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(LingoGreen)
            .border(2.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        // Cute owl eyes & beak
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                    )
                }
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFFFF9600))
            )
        }
    }
}

@Composable
fun MultipleChoiceOptions(
    options: List<String>,
    selectedOption: String?,
    correctAnswer: String,
    submissionState: StepSubmissionState,
    onOptionSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        options.forEachIndexed { index, option ->
            val isSelected = option == selectedOption
            val isCheckedCorrect = submissionState is StepSubmissionState.EvaluatedCorrect
            val isCheckedWrong = submissionState is StepSubmissionState.EvaluatedWrong

            val borderColor = when {
                isCheckedCorrect && isSelected -> LingoGreen
                isCheckedWrong && isSelected -> LingoRed
                isCheckedWrong && option == correctAnswer -> LingoGreen
                isSelected -> LingoBlue
                else -> LingoCardBorder
            }

            val backgroundColor = when {
                isCheckedCorrect && isSelected -> LingoGreenSubtle
                isCheckedWrong && isSelected -> LingoRedSubtle
                isCheckedWrong && option == correctAnswer -> LingoGreenSubtle
                isSelected -> LingoBlueLight
                else -> MaterialTheme.colorScheme.surface
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(2.dp, borderColor, RoundedCornerShape(16.dp))
                    .clickable(
                        enabled = submissionState is StepSubmissionState.Unanswered ||
                                submissionState is StepSubmissionState.Selected
                    ) {
                        onOptionSelected(option)
                    }
                    .testTag("option_card_$index"),
                color = backgroundColor,
                shadowElevation = if (isSelected) 3.dp else 1.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Badge number / indicator
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) LingoBlue else MaterialTheme.colorScheme.surfaceVariant
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCheckedCorrect && isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Correct",
                                tint = LingoGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        } else if (isCheckedWrong && isSelected) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Wrong",
                                tint = LingoRed,
                                modifier = Modifier.size(20.dp)
                            )
                        } else {
                            Text(
                                text = "${index + 1}",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Text(
                        text = option,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WordArrangementView(
    arrangedWords: List<String>,
    availableWords: List<String>,
    submissionState: StepSubmissionState,
    onAddWord: (word: String, index: Int) -> Unit,
    onRemoveWord: (word: String, index: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Arranged Word slots / destination line
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 100.dp)
                .border(2.dp, LingoCardBorder, RoundedCornerShape(16.dp))
                .testTag("arranged_words_container")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                if (arrangedWords.isEmpty()) {
                    Text(
                        text = "اضغط على الكلمات في الأسفل لتكوين الجملة هنا...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.align(Alignment.Center),
                        textAlign = TextAlign.Center
                    )
                } else {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        arrangedWords.forEachIndexed { index, word ->
                            WordChip(
                                word = word,
                                isSelected = true,
                                onClick = {
                                    if (submissionState is StepSubmissionState.Unanswered ||
                                        submissionState is StepSubmissionState.Selected
                                    ) {
                                        onRemoveWord(word, index)
                                    }
                                },
                                testTag = "arranged_word_$index"
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Word Bank area
        Text(
            text = "بنك الكلمات المتاحة:",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("available_words_bank"),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            availableWords.forEachIndexed { index, word ->
                WordChip(
                    word = word,
                    isSelected = false,
                    onClick = {
                        if (submissionState is StepSubmissionState.Unanswered ||
                            submissionState is StepSubmissionState.Selected
                        ) {
                            onAddWord(word, index)
                        }
                    },
                    testTag = "available_word_$index"
                )
            }
        }
    }
}

@Composable
fun WordChip(
    word: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Smooth bounce and press animation
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "word_chip_scale"
    )

    val chipBgColor = if (isSelected) {
        LingoWordButtonBg
    } else {
        if (isPressed) LingoWordButtonBgPressed else LingoWordButtonBg
    }

    val chipBorderColor = if (isSelected) {
        LingoNeonGreen
    } else {
        LingoWordButtonBorder
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = chipBgColor,
        shadowElevation = if (isPressed) 1.dp else 4.dp,
        modifier = modifier
            .scale(scale)
            .border(
                width = 2.dp,
                color = chipBorderColor,
                shape = RoundedCornerShape(14.dp)
            )
            .clip(RoundedCornerShape(14.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(
                    bounded = true,
                    color = LingoNeonGreen
                )
            ) { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = word,
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                fontWeight = FontWeight.ExtraBold,
                color = Color.White // Explicit pure white for perfect contrast
            )
        }
    }
}
