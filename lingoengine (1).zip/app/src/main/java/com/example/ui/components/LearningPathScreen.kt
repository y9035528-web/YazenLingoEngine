package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.LessonNode
import com.example.model.LessonNodeStatus
import com.example.model.UnitData

/**
 * Main Duolingo Learning Path screen displaying 10 Units and 10-Stage Zig-zag paths + 11th Treasure Chests.
 */
@Composable
fun LearningPathScreen(
    units: List<UnitData>,
    onSelectLesson: (LessonNode) -> Unit,
    onClaimTreasureChest: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeChestNode by remember { mutableStateOf<LessonNode?>(null) }
    var lockedStageHint by remember { mutableStateOf<String?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0B1320)) // High Contrast Dark Canvas
                .testTag("learning_path_screen")
        ) {
            items(units, key = { it.unitNumber }) { unit ->
                // Unit Header Banner
                UnitBanner(
                    unit = unit,
                    modifier = Modifier.fillMaxWidth()
                )

                // Only display interactive path if unit is unlocked
                if (unit.isUnlocked) {
                    LessonPathSection(
                        lessons = unit.lessons,
                        onSelectLesson = { lesson ->
                            if (lesson.isTreasureChest) {
                                activeChestNode = lesson
                            } else if (lesson.status == LessonNodeStatus.LOCKED) {
                                lockedStageHint = "المرحلة رقم ${lesson.stageNumber} مقفلة 🔒! يجب إكمال المراحل السابقة أولاً بنظام القفل المتسلسل الصارم."
                            } else {
                                onSelectLesson(lesson)
                            }
                        }
                    )
                }
            }
        }

        // Locked Stage Alert Dialog
        lockedStageHint?.let { hint ->
            AlertDialog(
                onDismissRequest = { lockedStageHint = null },
                containerColor = Color(0xFF1E293B),
                title = {
                    Text(
                        text = "المرحلة مقفلة 🔒",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                },
                text = {
                    Text(
                        text = hint,
                        color = Color(0xFFCBD5E1)
                    )
                },
                confirmButton = {
                    TextButton(onClick = { lockedStageHint = null }) {
                        Text("حسناً، فهمت", fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                    }
                }
            )
        }

        // Treasure Chest Animated Celebration / Modal Dialog
        activeChestNode?.let { chest ->
            val unit = units.find { it.unitNumber == chest.unitNumber }
            val completedCount = unit?.lessons?.count { !it.isTreasureChest && it.status == LessonNodeStatus.COMPLETED } ?: 0

            TreasureChestDialog(
                chestNode = chest,
                unitCompletedCount = completedCount,
                totalStagesInUnit = 10,
                onClaimReward = { unitNumber ->
                    onClaimTreasureChest(unitNumber)
                    activeChestNode = null
                },
                onDismiss = {
                    activeChestNode = null
                }
            )
        }
    }
}
