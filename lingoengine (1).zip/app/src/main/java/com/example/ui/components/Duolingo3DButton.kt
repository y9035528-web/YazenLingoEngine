package com.example.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.LingoBlue
import com.example.ui.theme.LingoBlueDark
import com.example.ui.theme.LingoGreen
import com.example.ui.theme.LingoGreenDark

/**
 * Authentic 3D Beveled Duolingo Button.
 * Features a darker bottom shadow layer that sinks realistically when pressed.
 */
@Composable
fun Duolingo3DButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    topColor: Color = LingoGreen,
    shadowColor: Color = LingoGreenDark,
    disabledTopColor: Color = Color(0xFFE5E7EB),
    disabledShadowColor: Color = Color(0xFFD1D5DB),
    bevelDepth: Dp = 4.dp,
    shape: Shape = RoundedCornerShape(16.dp),
    testTag: String = "duo_button",
    content: @Composable BoxScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val currentTopColor = if (enabled) topColor else disabledTopColor
    val currentShadowColor = if (enabled) shadowColor else disabledShadowColor

    val currentOffset by animateDpAsState(
        targetValue = if (isPressed && enabled) bevelDepth else 0.dp,
        label = "button_press_offset"
    )

    Box(
        modifier = modifier
            .testTag(testTag)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                onClick = onClick
            )
    ) {
        // Bottom 3D shadow layer
        Box(
            modifier = Modifier
                .matchParentSize()
                .offset(y = bevelDepth)
                .clip(shape)
                .background(currentShadowColor)
        )

        // Top interactive layer that presses down
        Box(
            modifier = Modifier
                .matchParentSize()
                .offset(y = currentOffset)
                .clip(shape)
                .background(currentTopColor),
            contentAlignment = Alignment.Center,
            content = content
        )
    }
}

/**
 * 3D Beveled Circular Duolingo Node Button (used for Lesson nodes on the Path).
 */
@Composable
fun Duolingo3DCircleButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 68.dp,
    bevelDepth: Dp = 5.dp,
    topColor: Color = LingoGreen,
    shadowColor: Color = LingoGreenDark,
    enabled: Boolean = true,
    testTag: String = "duo_circle_button",
    content: @Composable BoxScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val currentOffset by animateDpAsState(
        targetValue = if (isPressed && enabled) bevelDepth else 0.dp,
        label = "circle_button_press_offset"
    )

    Box(
        modifier = modifier
            .size(width = size, height = size + bevelDepth)
            .testTag(testTag)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                enabled = enabled,
                onClick = onClick
            ),
        contentAlignment = Alignment.TopCenter
    ) {
        // Bottom shadow circle
        Box(
            modifier = Modifier
                .size(size)
                .offset(y = bevelDepth)
                .clip(CircleShape)
                .background(shadowColor)
        )

        // Top main circle with sinking movement
        Box(
            modifier = Modifier
                .size(size)
                .offset(y = currentOffset)
                .clip(CircleShape)
                .background(topColor),
            contentAlignment = Alignment.Center,
            content = content
        )
    }
}
