package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PointsBalance
import com.example.ui.theme.LingoBlue
import com.example.ui.theme.LingoBlueDark
import com.example.ui.theme.LingoCardBorder
import com.example.ui.theme.LingoGreen
import com.example.ui.theme.LingoGreenDark
import com.example.ui.theme.LingoGreenLight
import com.example.ui.theme.LingoOrange
import com.example.ui.theme.LingoOrangeDark
import com.example.ui.theme.LingoPurple
import com.example.ui.theme.LingoPurpleDark
import com.example.ui.theme.LingoRed
import com.example.ui.theme.LingoYellow
import com.example.ui.theme.LingoYellowDark
import com.example.ui.theme.NunitoFontFamily

/**
 * Daily Practice & Review Screen
 */
@Composable
fun PracticeScreen(
    onStartPracticeSession: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "مركز التمارين والمراجعة اليومية 🏋️",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Text(
            text = "قوِّ مهاراتك من خلال تمارين استماع ومراجعة الأخطاء لتثبيت المفردات.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Practice Card 1: Daily Target
        PracticeActionCard(
            title = "المراجعة السريعة (تحدي اليوم)",
            subtitle = "أجب عن 5 أسئلة واكسب 20 XP فوري",
            icon = Icons.Default.Repeat,
            buttonText = "ابدأ المراجعة",
            cardColor = LingoBlue,
            cardShadowColor = LingoBlueDark,
            onAction = onStartPracticeSession
        )

        // Practice Card 2: Listening Gym
        PracticeActionCard(
            title = "نادي الاستماع والنطق",
            subtitle = "تدرّب على تمييز الأصوات ومخارج الحروف",
            icon = Icons.Default.Headphones,
            buttonText = "تمرين الاستماع",
            cardColor = LingoPurple,
            cardShadowColor = LingoPurpleDark,
            onAction = onStartPracticeSession
        )

        // Practice Card 3: Mistake Review
        PracticeActionCard(
            title = "مراجعة الأخطاء السابقة",
            subtitle = "أعد محاولة الأسئلة التي تعثرت فيها سابقاً",
            icon = Icons.Default.FitnessCenter,
            buttonText = "تصحيح الأخطاء",
            cardColor = LingoOrange,
            cardShadowColor = LingoOrangeDark,
            onAction = onStartPracticeSession
        )
    }
}

@Composable
private fun PracticeActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    buttonText: String,
    cardColor: Color,
    cardShadowColor: Color,
    onAction: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, LingoCardBorder, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(cardColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = cardColor,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Duolingo3DButton(
                onClick = onAction,
                topColor = cardColor,
                shadowColor = cardShadowColor,
                bevelDepth = 4.dp,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = buttonText,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

/**
 * Leaderboard & Weekly League Screen
 */
data class LeaderboardUser(
    val rank: Int,
    val name: String,
    val avatarEmoji: String,
    val xp: Int,
    val isCurrentUser: Boolean = false
)

@Composable
fun LeaderboardScreen(
    currentXp: Int,
    modifier: Modifier = Modifier
) {
    val users = listOf(
        LeaderboardUser(1, "سارة أحمد", "🥇", 450),
        LeaderboardUser(2, "عمر خالد", "🥈", 380),
        LeaderboardUser(3, "ليلى حسن", "🥉", 310),
        LeaderboardUser(4, "أنت (المتعلم)", "🦉", currentXp.coerceAtLeast(180), isCurrentUser = true),
        LeaderboardUser(5, "كريم نور", "⚡", 160),
        LeaderboardUser(6, "نادية منصور", "🌟", 140),
        LeaderboardUser(7, "يوسف طارق", "🚀", 120),
        LeaderboardUser(8, "مريم علي", "🎯", 95)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // League Header Banner
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFFFEF3C7),
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, LingoYellowDark, RoundedCornerShape(20.dp))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = "League",
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(42.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "دوري الياقوت الأسبوعي 💎",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF92400E)
                    )
                    Text(
                        text = "أفضل 5 متسابقين يصعدون إلى دوري الألماس بعد 3 أيام!",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFB45309)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "الترتيب الأسبوعي",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(users) { index, user ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (user.isCurrentUser) LingoGreenLight else MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = if (user.isCurrentUser) 2.dp else 1.dp,
                            color = if (user.isCurrentUser) LingoGreen else LingoCardBorder,
                            shape = RoundedCornerShape(16.dp)
                        )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "#${user.rank}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = when (user.rank) {
                                1 -> Color(0xFFD97706)
                                2 -> Color(0xFF64748B)
                                3 -> Color(0xFFB45309)
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.width(32.dp)
                        )

                        Text(
                            text = user.avatarEmoji,
                            fontSize = 24.sp
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Text(
                            text = user.name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (user.isCurrentUser) FontWeight.ExtraBold else FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )

                        Text(
                            text = "${user.xp} XP",
                            fontFamily = NunitoFontFamily,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = LingoYellowDark
                        )
                    }
                }
            }
        }
    }
}
