package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.model.QuestionType
import com.example.model.StepSubmissionState
import com.example.sound.AudioFeedbackHelper
import com.example.ui.LingoUiState
import com.example.ui.LingoViewModel
import com.example.ui.theme.LingoBlue
import com.example.ui.theme.LingoBlueLight

/**
 * The Interactive Step-by-Step Exercise Session view (Active quiz).
 * Supports listening questions with auto-speech, slow turtle audio playback,
 * snappy word pop sounds, and authentic Google Auth bottom sheet integration.
 */
@Composable
fun ExerciseSessionScreen(
    uiState: LingoUiState,
    audioHelper: AudioFeedbackHelper,
    viewModel: LingoViewModel,
    onCloseSession: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentExercise = uiState.currentExercise

    // Automatic TTS speech trigger when a listening question appears
    LaunchedEffect(currentExercise?.id) {
        if (currentExercise != null && currentExercise.type == QuestionType.LISTEN_SELECT) {
            audioHelper.speak(
                text = currentExercise.targetText,
                languageCode = currentExercise.languageCode,
                isSlow = false
            )
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .testTag("exercise_session_scaffold"),
        topBar = {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onCloseSession,
                        modifier = Modifier.testTag("close_exercise_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إنهاء الجلسة",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                LingoTopBar(
                    progress = uiState.progress,
                    pointsBalance = uiState.pointsBalance,
                    courseTitle = uiState.currentCourse.titleArabic,
                    courseFlag = uiState.currentCourse.flagEmoji,
                    onLanguageClick = { viewModel.toggleCourseSelector(true) },
                    onOpenJsonInspector = { viewModel.toggleJsonInspector(true) },
                    showProgressBar = true
                )
            }
        },
        bottomBar = {
            LingoBottomBar(
                submissionState = uiState.submissionState,
                canCheck = uiState.canCheckAnswer,
                onCheckAnswer = {
                    viewModel.submitAnswer { isCorrect ->
                        if (isCorrect) {
                            audioHelper.playSuccessFeedback()
                        } else {
                            audioHelper.playFailureFeedback()
                        }
                    }
                },
                onContinueNext = {
                    viewModel.nextStep()
                }
            )
        }
    ) { innerPadding ->
        val scrollState = rememberScrollState()
        val isEvaluated = uiState.submissionState is StepSubmissionState.EvaluatedCorrect ||
                uiState.submissionState is StepSubmissionState.EvaluatedWrong

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (currentExercise != null) {
                Spacer(modifier = Modifier.height(8.dp))

                // Exercise Header (Prompt, Mascot speech bubble, Normal & Slow Audio buttons)
                ExercisePromptHeader(
                    exercise = currentExercise,
                    isEvaluated = isEvaluated,
                    onPlayAudio = {
                        audioHelper.speak(
                            text = currentExercise.targetText,
                            languageCode = currentExercise.languageCode,
                            isSlow = false
                        )
                    },
                    onPlaySlowAudio = {
                        audioHelper.speak(
                            text = currentExercise.targetText,
                            languageCode = currentExercise.languageCode,
                            isSlow = true
                        )
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Fill in blank special banner if present
                if (currentExercise.type == QuestionType.FILL_BLANK && currentExercise.sentenceWithBlank != null) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = LingoBlueLight,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = currentExercise.sentenceWithBlank,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = LingoBlue,
                            modifier = Modifier.padding(14.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Exercise Options Interaction
                when (currentExercise.type) {
                    QuestionType.MULTIPLE_CHOICE, QuestionType.FILL_BLANK, QuestionType.LISTEN_SELECT -> {
                        MultipleChoiceOptions(
                            options = currentExercise.options,
                            selectedOption = uiState.selectedOption,
                            correctAnswer = currentExercise.correctAnswer,
                            submissionState = uiState.submissionState,
                            onOptionSelected = { option ->
                                audioHelper.playWordTapClick()
                                viewModel.selectOption(option)
                            }
                        )
                    }

                    QuestionType.WORD_ARRANGE -> {
                        WordArrangementView(
                            arrangedWords = uiState.arrangedWords,
                            availableWords = uiState.availableWords,
                            submissionState = uiState.submissionState,
                            onAddWord = { word, index ->
                                audioHelper.playWordTapClick()
                                viewModel.addWordToArranged(word, index)
                            },
                            onRemoveWord = { word, index ->
                                audioHelper.playWordTapClick()
                                viewModel.removeWordFromArranged(word, index)
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
