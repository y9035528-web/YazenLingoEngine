package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LessonNode
import com.example.model.LessonNodeStatus
import com.example.model.UnitData
import com.example.ui.theme.LingoBlue
import com.example.ui.theme.LingoBlueDark
import com.example.ui.theme.LingoGreen
import com.example.ui.theme.LingoGreenDark
import com.example.ui.theme.LingoLockedGray
import com.example.ui.theme.LingoLockedGrayDark
import com.example.ui.theme.LingoLockedText
import com.example.ui.theme.LingoYellow
import com.example.ui.theme.LingoYellowDark
import com.example.ui.theme.NunitoFontFamily

/**
 * Unit Banner Header with Guidebook modal
 */
@Composable
fun UnitBanner(
    unit: UnitData,
    modifier: Modifier = Modifier
) {
    var showGuidebookDialog by remember { mutableStateOf(false) }
    val isUnlocked = unit.isUnlocked
    val baseColor = Color(unit.colorHex)
    val bannerColor = if (isUnlocked) baseColor else Color(0xFF1E293B)
    val bannerShadowColor = if (isUnlocked) {
        if (baseColor == LingoBlue) LingoBlueDark else LingoGreenDark
    } else Color(0xFF0F172A)

    Duolingo3DButton(
        onClick = { if (isUnlocked) showGuidebookDialog = true },
        topColor = bannerColor,
        shadowColor = bannerShadowColor,
        bevelDepth = 5.dp,
        shape = RoundedCornerShape(18.dp),
        testTag = "unit_banner_${unit.unitNumber}",
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!isUnlocked) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Locked",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    } else if (unit.isCompleted) {
                        Text(text = "👑", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = unit.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isUnlocked) Color.White else Color(0xFF94A3B8)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isUnlocked) unit.description else "أكمل وافتح صندوق كنز الوحدة السابقة لفتح هذا المستوى 🔒",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isUnlocked) Color.White.copy(alpha = 0.9f) else Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Guidebook pill button or lock indicator
            if (isUnlocked) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.25f),
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Book,
                            contentDescription = "دليل القواعد",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "دليل الوحدة",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0F172A)
                ) {
                    Text(
                        text = "مغلق 🔒",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }

    // Guidebook Dialog
    if (showGuidebookDialog) {
        AlertDialog(
            onDismissRequest = { showGuidebookDialog = false },
            shape = RoundedCornerShape(20.dp),
            containerColor = MaterialTheme.colorScheme.surface,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "دليل ${unit.title}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold
                    )
                    IconButton(onClick = { showGuidebookDialog = false }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = unit.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "نصائح وإرشادات سريعة:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    unit.guideBookTips.forEach { tip ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = tip,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showGuidebookDialog = false }) {
                    Text("حسناً، فهمت", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

/**
 * Zig-Zag Path Section with dotted connector line
 */
@Composable
fun LessonPathSection(
    lessons: List<LessonNode>,
    onSelectLesson: (LessonNode) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        lessons.forEachIndexed { index, lesson ->
            // Lesson Node with horizontal zig-zag offset
            val xOffset = (lesson.xOffsetFactor * 75).dp

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                LessonNodeItem(
                    lesson = lesson,
                    onClick = { onSelectLesson(lesson) },
                    modifier = Modifier.offset(x = xOffset)
                )
            }

            // Dotted connector path to next node
            if (index < lessons.size - 1) {
                val nextLesson = lessons[index + 1]
                val currentX = lesson.xOffsetFactor * 75
                val nextX = nextLesson.xOffsetFactor * 75
                val isPathCompleted = lesson.status == LessonNodeStatus.COMPLETED

                Canvas(
                    modifier = Modifier
                        .width(220.dp)
                        .height(38.dp)
                ) {
                    val startX = (size.width / 2) + currentX.dp.toPx()
                    val endX = (size.width / 2) + nextX.dp.toPx()

                    drawLine(
                        color = if (isPathCompleted) LingoYellow.copy(alpha = 0.85f) else Color(0xFF334155),
                        start = Offset(startX, 0f),
                        end = Offset(endX, size.height),
                        strokeWidth = 6.dp.toPx(),
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 16f), 0f)
                    )
                }
            }
        }
    }
}

/**
 * Single 3D Lesson Node or Prominent Glowing Treasure Chest on the Zig-zag Path
 */
@Composable
fun LessonNodeItem(
    lesson: LessonNode,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.09f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "current_node_scale"
    )

    val chestGlowAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000),
            repeatMode = RepeatMode.Restart
        ),
        label = "chest_glow_angle"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(
            contentAlignment = Alignment.Center
        ) {
            // SPECIAL HANDLING: TREASURE CHEST NODE
            if (lesson.isTreasureChest) {
                when {
                    lesson.isChestClaimed -> {
                        // Already opened & claimed
                        Duolingo3DCircleButton(
                            onClick = onClick,
                            size = 86.dp,
                            bevelDepth = 6.dp,
                            topColor = Color(0xFFD97706),
                            shadowColor = Color(0xFF92400E),
                            testTag = "treasure_chest_claimed_${lesson.unitNumber}"
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(text = "🏆", fontSize = 38.sp)
                            }
                        }
                    }

                    lesson.status == LessonNodeStatus.CURRENT -> {
                        // UNLOCKED & READY TO CLAIM: Radiant Glowing & Pulsing Animation
                        Box(
                            modifier = Modifier.scale(pulseScale),
                            contentAlignment = Alignment.Center
                        ) {
                            // Sparkling Halo
                            Box(
                                modifier = Modifier
                                    .size(114.dp)
                                    .clip(CircleShape)
                                    .background(
                                        androidx.compose.ui.graphics.Brush.radialGradient(
                                            colors = listOf(
                                                Color(0xFFFFD700).copy(alpha = 0.6f),
                                                Color(0xFFF59E0B).copy(alpha = 0.25f),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )

                            Duolingo3DCircleButton(
                                onClick = onClick,
                                size = 92.dp,
                                bevelDepth = 7.dp,
                                topColor = LingoYellow,
                                shadowColor = LingoYellowDark,
                                testTag = "treasure_chest_ready_${lesson.unitNumber}"
                            ) {
                                Text(
                                    text = "🎁",
                                    fontSize = 44.sp
                                )
                            }
                        }
                    }

                    else -> {
                        // LOCKED CHEST
                        Duolingo3DCircleButton(
                            onClick = onClick,
                            size = 86.dp,
                            bevelDepth = 5.dp,
                            topColor = Color(0xFF1E293B),
                            shadowColor = Color(0xFF0F172A),
                            testTag = "treasure_chest_locked_${lesson.unitNumber}"
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(text = "🎁", fontSize = 36.sp, modifier = Modifier.scale(0.85f))
                                Box(
                                    modifier = Modifier
                                        .size(26.dp)
                                        .align(Alignment.BottomEnd)
                                        .clip(CircleShape)
                                        .background(Color(0xFF0F172A)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Locked Chest",
                                        tint = Color(0xFF94A3B8),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // REGULAR LEARNING STAGE NODE
                when (lesson.status) {
                    LessonNodeStatus.COMPLETED -> {
                        // Golden/Green Completed Node
                        Duolingo3DCircleButton(
                            onClick = onClick,
                            size = 72.dp,
                            bevelDepth = 6.dp,
                            topColor = LingoYellow,
                            shadowColor = LingoYellowDark,
                            testTag = "lesson_node_completed_${lesson.id}"
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Completed",
                                    tint = Color.White,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }
                    }

                    LessonNodeStatus.CURRENT -> {
                        // Glowing / Pulsing active node with progress ring
                        Box(
                            modifier = Modifier.scale(pulseScale),
                            contentAlignment = Alignment.Center
                        ) {
                            // Outer Progress indicator ring
                            CircularProgressIndicator(
                                progress = { lesson.completedSteps.toFloat() / lesson.totalSteps.coerceAtLeast(1).toFloat() },
                                modifier = Modifier.size(86.dp),
                                color = LingoGreen,
                                trackColor = LingoGreen.copy(alpha = 0.2f),
                                strokeWidth = 5.dp
                            )

                            Duolingo3DCircleButton(
                                onClick = onClick,
                                size = 72.dp,
                                bevelDepth = 6.dp,
                                topColor = LingoGreen,
                                shadowColor = LingoGreenDark,
                                testTag = "lesson_node_current_${lesson.id}"
                            ) {
                                Text(
                                    text = lesson.iconEmoji,
                                    fontSize = 32.sp
                                )
                            }
                        }
                    }

                    LessonNodeStatus.LOCKED -> {
                        // Gray 3D locked node with dark styling
                        Duolingo3DCircleButton(
                            onClick = onClick,
                            size = 70.dp,
                            bevelDepth = 5.dp,
                            topColor = Color(0xFF1E293B),
                            shadowColor = Color(0xFF0F172A),
                            testTag = "lesson_node_locked_${lesson.id}"
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Locked",
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Label beneath node with High-Contrast typography
        if (lesson.isTreasureChest) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = when {
                    lesson.isChestClaimed -> Color(0xFF0F172A)
                    lesson.status == LessonNodeStatus.CURRENT -> LingoYellow
                    else -> Color(0xFF1E293B)
                },
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (lesson.status == LessonNodeStatus.CURRENT) LingoYellowDark else Color(0xFF334155)
                )
            ) {
                Text(
                    text = when {
                        lesson.isChestClaimed -> "الكنز مستلم ✓"
                        lesson.status == LessonNodeStatus.CURRENT -> "افتح الكنز! 🎁"
                        else -> "صندوق الكنز (+100 XP)"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (lesson.status == LessonNodeStatus.CURRENT) Color(0xFF78350F) else Color(0xFFCBD5E1),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            Text(
                text = "${lesson.stageNumber}. ${lesson.title}",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = if (lesson.status == LessonNodeStatus.LOCKED) Color(0xFF64748B) else Color.White,
                textAlign = TextAlign.Center
            )
        }
    }
}
