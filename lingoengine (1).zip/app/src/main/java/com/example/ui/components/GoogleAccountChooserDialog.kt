package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LingoGreen
import com.example.ui.theme.LingoGreenDark

data class GoogleAccountInfo(
    val email: String,
    val displayName: String,
    val avatarBgColor: Color,
    val isPrimary: Boolean = false
)

/**
 * High-Contrast Google Account Chooser Bottom Sheet dialog adhering to official Google Sign-In identity specs.
 * Provides pre-saved accounts list, clear "Add another account" flow, and "Create new account" actions.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoogleAccountChooserDialog(
    currentSignedInEmail: String?,
    isCurrentlySignedIn: Boolean,
    onSelectAccount: (GoogleAccountInfo) -> Unit,
    onSignOut: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var savedAccounts by remember {
        mutableStateOf(
            listOf(
                GoogleAccountInfo(
                    email = "y9035528@gmail.com",
                    displayName = "Yousef (المستخدم الأساسي)",
                    avatarBgColor = Color(0xFF4285F4),
                    isPrimary = true
                ),
                GoogleAccountInfo(
                    email = "lingo.learner@gmail.com",
                    displayName = "Lingo Learner",
                    avatarBgColor = Color(0xFF34A853),
                    isPrimary = false
                )
            )
        )
    }

    var showAddAccountForm by remember { mutableStateOf(false) }
    var newEmailInput by remember { mutableStateOf("") }
    var newNameInput by remember { mutableStateOf("") }
    var inputError by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF131D2E), // Dark high-contrast navy background
        tonalElevation = 12.dp,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        modifier = modifier.testTag("google_account_chooser_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Row: Google G emblem + Close button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Google "G" Badge with official colors
                GoogleMulticolorLogoBadge()

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_google_dialog_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title & Subtitle in crisp high contrast white
            Text(
                text = "تسجيل الدخول باستخدام Google",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                ),
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("google_dialog_title")
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "اختر حسابك للمتابعة إلى Yazen lingo Engine ومزامنة نقاط الخبرة XP والتقدم في السحابة.",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFCBD5E1),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            HorizontalDivider(color = Color(0xFF334155), thickness = 1.dp)

            Spacer(modifier = Modifier.height(16.dp))

            // List of Saved Accounts
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                savedAccounts.forEachIndexed { index, account ->
                    val isThisAccountActive = isCurrentlySignedIn && account.email.equals(currentSignedInEmail, ignoreCase = true)

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isThisAccountActive) Color(0xFF1E293B) else Color(0xFF1A2638),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isThisAccountActive) 2.dp else 1.dp,
                                color = if (isThisAccountActive) LingoGreen else Color(0xFF334155),
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable {
                                onSelectAccount(account)
                                onDismiss()
                            }
                            .testTag("google_account_item_$index")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Avatar with initials
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(account.avatarBgColor)
                                    .border(1.5.dp, Color.White.copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = account.displayName.firstOrNull()?.uppercase() ?: "G",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = account.displayName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    if (account.isPrimary) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFF2563EB))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "الأساسي",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                Text(
                                    text = account.email,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF94A3B8)
                                )
                            }

                            if (isThisAccountActive) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(LingoGreen),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Active",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action: "إضافة حساب آخر" (Add another account)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF475569), RoundedCornerShape(14.dp))
                    .clickable {
                        showAddAccountForm = !showAddAccountForm
                    }
                    .testTag("add_another_account_button")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF334155)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "إضافة حساب",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Text(
                        text = if (showAddAccountForm) "إلغاء إضافة الحساب" else "إضافة حساب آخر (Add another account)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Inline Add Account Form
            AnimatedVisibility(visible = showAddAccountForm) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.5.dp, Color(0xFF38BDF8), RoundedCornerShape(16.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "إدخال بيانات حساب Google الجديد:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = newEmailInput,
                        onValueChange = {
                            newEmailInput = it
                            inputError = null
                        },
                        label = { Text("البريد الإلكتروني (Gmail)", color = Color(0xFF94A3B8)) },
                        placeholder = { Text("example@gmail.com", color = Color(0xFF64748B)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF475569)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_google_email_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newNameInput,
                        onValueChange = { newNameInput = it },
                        label = { Text("الاسم الكامل", color = Color(0xFF94A3B8)) },
                        placeholder = { Text("اسم المستخدم", color = Color(0xFF64748B)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = Color(0xFF475569)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_google_name_input")
                    )

                    if (inputError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = inputError.orEmpty(),
                            color = Color(0xFFFF4B4B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Duolingo3DButton(
                        onClick = {
                            val trimmedEmail = newEmailInput.trim()
                            if (trimmedEmail.isBlank() || !trimmedEmail.contains("@")) {
                                inputError = "يرجى إدخال عنوان بريد إلكتروني صالح."
                                return@Duolingo3DButton
                            }
                            val displayName = newNameInput.trim().ifBlank { trimmedEmail.substringBefore("@") }
                            val newAccount = GoogleAccountInfo(
                                email = trimmedEmail,
                                displayName = displayName,
                                avatarBgColor = Color(0xFFEA4335)
                            )
                            savedAccounts = savedAccounts + newAccount
                            onSelectAccount(newAccount)
                            onDismiss()
                        },
                        topColor = Color(0xFF2563EB),
                        shadowColor = Color(0xFF1D4ED8),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("submit_new_google_account_button")
                    ) {
                        Text(
                            text = "تسجيل الدخول ومزامنة الحساب 🚀",
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action: "إنشاء حساب Google جديد" (Create new account)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E293B),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF475569), RoundedCornerShape(14.dp))
                    .clickable {
                        val newAccount = GoogleAccountInfo(
                            email = "new.learner.${System.currentTimeMillis() % 1000}@gmail.com",
                            displayName = "متعلم جديد (Google User)",
                            avatarBgColor = Color(0xFFFBBC05)
                        )
                        savedAccounts = savedAccounts + newAccount
                        onSelectAccount(newAccount)
                        onDismiss()
                    }
                    .testTag("create_new_account_button")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF334155)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = "إنشاء حساب",
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Text(
                        text = "إنشاء حساب Google جديد (Create new account)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // Sign out button if already signed in
            if (isCurrentlySignedIn) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF2C151B),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                        .clickable {
                            onSignOut()
                            onDismiss()
                        }
                        .testTag("google_sign_out_button")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "تسجيل الخروج",
                            tint = Color(0xFFF87171),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تسجيل الخروج من الحساب الحالي",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF87171)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Privacy & Terms disclaimer
            Text(
                text = "لمتابعة الاستخدام، ستشارك Google اسمك وعنوان بريدك الإلكتروني مع تطبيق Yazen lingo Engine بموجب بنود الخدمة وسياسة الخصوصية.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

/**
 * Official Google "G" multicolor emblem.
 */
@Composable
fun GoogleMulticolorLogoBadge(modifier: Modifier = Modifier) {
    Surface(
        shape = CircleShape,
        color = Color.White,
        shadowElevation = 4.dp,
        modifier = modifier.size(46.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = "G",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFF4285F4)
            )
        }
    }
}
