package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LeagueTier
import com.example.ui.theme.LingoGreen
import com.example.ui.theme.LingoGreenDark
import com.example.ui.theme.LingoYellow
import com.example.ui.theme.LingoYellowDark
import com.example.ui.theme.NunitoFontFamily

data class Competitor(
    val id: String,
    val name: String,
    val avatarEmoji: String,
    val xp: Int,
    val isUser: Boolean = false,
    val streak: Int = 3
)

@Composable
fun LeaguesScreen(
    currentXp: Int,
    userName: String = "أنت",
    userAvatar: String = "🦉",
    onPlayLessonToClimb: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val currentLeague = LeagueTier.fromXp(currentXp)
    var selectedTierView by remember(currentLeague) { mutableStateOf(currentLeague) }

    // Next tier calculation
    val allTiers = LeagueTier.values()
    val currentTierIndex = allTiers.indexOf(currentLeague)
    val nextTier = if (currentTierIndex < allTiers.size - 1) allTiers[currentTierIndex + 1] else null

    val xpForNextTier = nextTier?.minXp ?: currentLeague.maxXp
    val xpNeeded = (xpForNextTier - currentXp).coerceAtLeast(0)
    val tierRange = (xpForNextTier - currentLeague.minXp).coerceAtLeast(1)
    val currentProgressInTier = ((currentXp - currentLeague.minXp).toFloat() / tierRange.toFloat()).coerceIn(0f, 1f)

    // Build dynamic list of competitors based on current league tier
    val baseBots = remember(currentLeague) {
        generateBotsForLeague(currentLeague)
    }

    val userCompetitor = Competitor(
        id = "current_user",
        name = "$userName (المتعلم)",
        avatarEmoji = userAvatar,
        xp = currentXp,
        isUser = true
    )

    // Combine and sort by XP descending
    val sortedLeaderboard = remember(currentXp, baseBots, userName, userAvatar) {
        (baseBots.filterNot { it.isUser } + userCompetitor).sortedByDescending { it.xp }
    }

    val userRank = sortedLeaderboard.indexOfFirst { it.isUser } + 1

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_trophy")
    val trophyScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100),
            repeatMode = RepeatMode.Reverse
        ),
        label = "trophy_scale"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B1320)) // Dark High Contrast Base
            .padding(horizontal = 16.dp)
            .testTag("leagues_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))

            // Main Active League Header Banner
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF1E293B),
                border = androidx.compose.foundation.BorderStroke(
                    2.dp,
                    Color(currentLeague.colorHex)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("current_league_banner")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentLeague.badgeEmoji,
                                fontSize = 42.sp,
                                modifier = Modifier.scale(trophyScale)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = currentLeague.titleArabic,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(currentLeague.colorHex)
                                )
                                Text(
                                    text = currentLeague.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }

                        // Countdown Pill
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF0F172A),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = "Timer",
                                    tint = LingoYellow,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "2 يوم و 14 ساعة",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress Bar to Next League
                    if (nextTier != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "متبقي $xpNeeded XP للترقية إلى ${nextTier.titleArabic} ${nextTier.badgeEmoji}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "$currentXp / $xpForNextTier XP",
                                fontFamily = NunitoFontFamily,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(currentLeague.colorHex)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { currentProgressInTier },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp)),
                            color = Color(currentLeague.colorHex),
                            trackColor = Color(0xFF334155)
                        )
                    } else {
                        // Max Tier reached (Diamond)
                        Text(
                            text = "👑 أنت في قمة رتب دوريات Yazen lingo Engine (دوري الألماس)!",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF38BDF8)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // User current ranking badge
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0F172A))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "ترتيبك الحالي في الدوري:",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFCBD5E1)
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "#$userRank",
                                fontFamily = NunitoFontFamily,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = when (userRank) {
                                    1 -> LingoYellow
                                    2 -> Color(0xFFC0C0C0)
                                    3 -> Color(0xFFCD7F32)
                                    in 4..8 -> Color(0xFF38BDF8)
                                    else -> Color(0xFFF43F5E)
                                }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (userRank <= 3) "منطقة الترقية ⬆️" else if (userRank <= 8) "منطقة البقاء 🛡️" else "خطر الهبوط ⚠️",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (userRank <= 3) LingoGreen else if (userRank <= 8) Color(0xFF94A3B8) else Color(0xFFF43F5E)
                            )
                        }
                    }
                }
            }
        }

        // Horizontal 5 Tiers Showcase Selector
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "رتب وبطولات اللعبة (5 مستويات)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LeagueTier.values().forEach { tier ->
                        val isCurrentPlayerTier = tier == currentLeague
                        val isSelected = tier == selectedTierView

                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) Color(0xFF1E293B) else Color(0xFF0F172A),
                            border = androidx.compose.foundation.BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) Color(tier.colorHex) else Color(0xFF334155)
                            ),
                            modifier = Modifier
                                .clickable { selectedTierView = tier }
                                .padding(vertical = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(text = tier.badgeEmoji, fontSize = 24.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = tier.titleArabic,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color(tier.colorHex) else Color(0xFF94A3B8)
                                )
                                Text(
                                    text = "${tier.minXp}+ XP",
                                    fontFamily = NunitoFontFamily,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF64748B)
                                )
                                if (isCurrentPlayerTier) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "رتبتك الحالية",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = LingoGreen
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Leaderboard Title & Promotion Zone Legend
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "المتصدرون هذا الأسبوع",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(LingoGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "المراكز 1-3 ترقية",
                            style = MaterialTheme.typography.labelSmall,
                            color = LingoGreen
                        )
                    }
                }
            }
        }

        // Leaderboard List
        itemsIndexed(sortedLeaderboard, key = { _, comp -> comp.id }) { index, competitor ->
            val rank = index + 1
            val isUser = competitor.isUser

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = when {
                    isUser -> Color(0xFF1E3A8A).copy(alpha = 0.85f) // Glowing Royal Blue for User
                    rank <= 3 -> Color(0xFF1E293B)
                    else -> Color(0xFF0F172A)
                },
                border = androidx.compose.foundation.BorderStroke(
                    width = if (isUser) 2.5.dp else if (rank <= 3) 1.5.dp else 1.dp,
                    color = when {
                        isUser -> Color(0xFF38BDF8)
                        rank == 1 -> LingoYellow
                        rank == 2 -> Color(0xFFC0C0C0)
                        rank == 3 -> Color(0xFFCD7F32)
                        else -> Color(0xFF334155)
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag(if (isUser) "leaderboard_user_row" else "leaderboard_bot_row_$rank")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Rank Number / Medal
                    Box(
                        modifier = Modifier.width(36.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = when (rank) {
                                1 -> "🥇"
                                2 -> "🥈"
                                3 -> "🥉"
                                else -> "#$rank"
                            },
                            style = MaterialTheme.typography.titleSmall,
                            fontFamily = if (rank > 3) NunitoFontFamily else null,
                            fontWeight = FontWeight.ExtraBold,
                            color = when (rank) {
                                1 -> LingoYellow
                                2 -> Color(0xFFC0C0C0)
                                3 -> Color(0xFFCD7F32)
                                in 4..8 -> Color(0xFF94A3B8)
                                else -> Color(0xFFF43F5E)
                            }
                        )
                    }

                    // Avatar
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                if (isUser) Color(0xFF2563EB) else Color(0xFF334155)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = competitor.avatarEmoji,
                            fontSize = 20.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Name + User Badge
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = competitor.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isUser) FontWeight.ExtraBold else FontWeight.Bold,
                                color = if (isUser) Color.White else Color(0xFFE2E8F0)
                            )
                            if (isUser) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = LingoGreen
                                ) {
                                    Text(
                                        text = "أنت",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // Subtext (Promotion status / Streak)
                        Text(
                            text = when {
                                rank <= 3 -> "منطقة الصعود إلى ${nextTier?.titleArabic ?: "دوري النخبة"} 🚀"
                                rank in 4..8 -> "منطقة الأمان (البقاء في الدوري) 🛡️"
                                else -> "خطر الهبوط إلى الدوري السابق ⚠️"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = when {
                                rank <= 3 -> LingoGreen
                                rank in 4..8 -> Color(0xFF94A3B8)
                                else -> Color(0xFFF43F5E)
                            }
                        )
                    }

                    // XP Score
                    Text(
                        text = "${competitor.xp} XP",
                        fontFamily = NunitoFontFamily,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isUser) Color(0xFFFFD700) else Color(0xFFCBD5E1)
                    )
                }
            }
        }

        // Action CTA Banner to play lesson and climb
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Duolingo3DButton(
                onClick = onPlayLessonToClimb,
                topColor = LingoGreen,
                shadowColor = LingoGreenDark,
                bevelDepth = 5.dp,
                shape = RoundedCornerShape(18.dp),
                testTag = "climb_league_play_button",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "العب درساً لزيادة نقاطك والتصدر ⚡",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * Generates realistic competitor bots for the specific league tier.
 */
private fun generateBotsForLeague(league: LeagueTier): List<Competitor> {
    val (min, max) = when (league) {
        LeagueTier.BRONZE -> 20 to 140
        LeagueTier.SILVER -> 160 to 340
        LeagueTier.GOLD -> 360 to 690
        LeagueTier.RUBY -> 720 to 1180
        LeagueTier.DIAMOND -> 1220 to 2200
    }

    val botNames = listOf(
        Pair("سارة أحمد", "🧕"),
        Pair("عمر خالد", "👨‍💻"),
        Pair("ليلى نور", "👩‍🎨"),
        Pair("كريم إبراهيم", "🚀"),
        Pair("نادية منصور", "🌟"),
        Pair("يوسف طارق", "⚡"),
        Pair("مريم الدوسري", "🎯"),
        Pair("أحمد الغامدي", "🦁"),
        Pair("فاطمة الزهراء", "🌸"),
        Pair("طارق الشهري", "🔥")
    )

    val step = (max - min) / (botNames.size)
    return botNames.mapIndexed { index, (name, emoji) ->
        val xp = max - (index * step) + ((index * 7) % 15)
        Competitor(
            id = "bot_$index",
            name = name,
            avatarEmoji = emoji,
            xp = xp,
            isUser = false,
            streak = 2 + (index % 5)
        )
    }
}
