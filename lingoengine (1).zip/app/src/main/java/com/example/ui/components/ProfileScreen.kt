package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PointsBalance
import com.example.ui.theme.LingoBlue
import com.example.ui.theme.LingoBlueDark
import com.example.ui.theme.LingoCardBorder
import com.example.ui.theme.LingoGreen
import com.example.ui.theme.LingoGreenDark
import com.example.ui.theme.LingoOrange
import com.example.ui.theme.LingoPurple
import com.example.ui.theme.LingoRed
import com.example.ui.theme.LingoYellowDark
import com.example.ui.theme.NunitoFontFamily

/**
 * Dedicated Profile and Account Screen for Yazen lingo Engine.
 * Houses genuine Google sign-in status, user avatar, email, cloud sync, and account switching / sign out.
 */
@Composable
fun ProfileScreen(
    pointsBalance: PointsBalance,
    courseTitle: String,
    courseFlag: String,
    isGoogleSignedIn: Boolean,
    userGoogleEmail: String,
    userGoogleName: String,
    onOpenGoogleAccountChooser: () -> Unit,
    onSignOutGoogle: () -> Unit,
    onRefillHearts: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ==========================================
        // 1. Google Account Header Card
        // ==========================================
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = Color(0xFF131F2E),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 2.dp,
                    color = if (isGoogleSignedIn) Color(0xFF38BDF8) else Color(0xFF334155),
                    shape = RoundedCornerShape(22.dp)
                )
                .testTag("profile_account_card")
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Profile Avatar with Google brand accents
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .clip(CircleShape)
                        .background(
                            if (isGoogleSignedIn) Color(0xFF1E3A8A) else Color(0xFF1E293B)
                        )
                        .border(
                            width = 3.5.dp,
                            color = if (isGoogleSignedIn) Color(0xFF38BDF8) else Color(0xFF475569),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isGoogleSignedIn) {
                        Text(
                            text = userGoogleName.firstOrNull()?.uppercase() ?: "G",
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    } else {
                        Text(
                            text = "🦉",
                            fontSize = 48.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Display Name
                Text(
                    text = if (isGoogleSignedIn) userGoogleName else "المتعلم الضيف",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    fontSize = 22.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Email Address
                Text(
                    text = if (isGoogleSignedIn) userGoogleEmail else "حساب زائر غير مسجل",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = if (isGoogleSignedIn) Color(0xFF93C5FD) else Color(0xFF94A3B8),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Sync Status Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (isGoogleSignedIn) Color(0xFF064E3B) else Color(0xFF1E293B),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isGoogleSignedIn) Color(0xFF10B981) else Color(0xFF475569)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isGoogleSignedIn) Icons.Default.CheckCircle else Icons.Default.Shield,
                            contentDescription = null,
                            tint = if (isGoogleSignedIn) Color(0xFF34D399) else Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isGoogleSignedIn) "متزامن مع سحابة Google ✓" else "التقدم محفوظ محلياً فقط",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isGoogleSignedIn) Color(0xFFD1FAE5) else Color(0xFFE2E8F0)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons for Account Management
                if (isGoogleSignedIn) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Switch / Manage Account Button
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF1E293B),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .border(1.dp, Color(0xFF475569), RoundedCornerShape(14.dp))
                                .clickable { onOpenGoogleAccountChooser() }
                                .testTag("profile_switch_account_button")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwitchAccount,
                                    contentDescription = null,
                                    tint = Color(0xFF38BDF8),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "إدارة أو تبديل حساب Google",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        // Sign Out Button
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF2D1214),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .border(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                                .clickable { onSignOutGoogle() }
                                .testTag("profile_sign_out_button")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                                    contentDescription = null,
                                    tint = Color(0xFFF87171),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "تسجيل الخروج من الحساب",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFCA5A5)
                                )
                            }
                        }
                    }
                } else {
                    // Not signed in: Show prominent Google Sign-in action
                    GoogleSignInButton(
                        isSignedIn = false,
                        userEmail = "",
                        onSignInClick = onOpenGoogleAccountChooser
                    )
                }
            }
        }

        // ==========================================
        // 2. Active Course Pill
        // ==========================================
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFF1E293B),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = courseFlag, fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "المسار التعليمي النشط",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF94A3B8)
                        )
                        Text(
                            text = courseTitle,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }
                Text(
                    text = "مستوى متقدم",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = LingoGreen
                )
            }
        }

        // ==========================================
        // 3. Learning Statistics Grid (4 High-Contrast Cards)
        // ==========================================
        Text(
            text = "إحصائيات الإنجاز والنقاط 📊",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ProfileStatCard(
                title = "أيام الاستمرار",
                value = "${pointsBalance.streakDays} يوم",
                icon = Icons.Default.LocalFireDepartment,
                iconColor = LingoOrange,
                modifier = Modifier.weight(1f)
            )

            ProfileStatCard(
                title = "رصيد الخبرة",
                value = "${pointsBalance.totalXp} XP",
                icon = Icons.Default.Star,
                iconColor = LingoYellowDark,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ProfileStatCard(
                title = "المحاولات (القلوب)",
                value = "${pointsBalance.heartsRemaining}/5",
                icon = Icons.Default.Favorite,
                iconColor = LingoRed,
                modifier = Modifier.weight(1f)
            )

            ProfileStatCard(
                title = "الرتبة والدوري",
                value = "دوري الياقوت",
                icon = Icons.Default.EmojiEvents,
                iconColor = LingoBlue,
                modifier = Modifier.weight(1f)
            )
        }

        // Refill hearts button if hearts < 5
        if (pointsBalance.heartsRemaining < 5) {
            Duolingo3DButton(
                onClick = onRefillHearts,
                topColor = LingoGreen,
                shadowColor = LingoGreenDark,
                bevelDepth = 4.dp,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "شحن القلوب للحد الأقصى (5/5) مجاناً",
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
            }
        }

        // ==========================================
        // 4. Badges & Milestones Section
        // ==========================================
        Text(
            text = "الأوسمة والإنجازات المكتسبة 🏅",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
        )

        Surface(
            shape = RoundedCornerShape(18.dp),
            color = Color(0xFF131F2E),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF334155), RoundedCornerShape(18.dp))
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BadgeItem(
                    title = "انطلاقة البطل 🚀",
                    subtitle = "أكملت أول درس بنجاح واكتسبت نقاط XP",
                    icon = Icons.Default.Star,
                    iconColor = Color(0xFFFFC800),
                    isUnlocked = true
                )
                BadgeItem(
                    title = "أذن ذهبية خارقة 🎧",
                    subtitle = "أتقنت تمارين الاستماع والتمييز الصوتي بدقة",
                    icon = Icons.Default.Headphones,
                    iconColor = LingoPurple,
                    isUnlocked = true
                )
                BadgeItem(
                    title = "المثابر المحترف 🔥",
                    subtitle = "حافظ على حماسك لمدة 3 أيام متتالية",
                    icon = Icons.Default.LocalFireDepartment,
                    iconColor = LingoOrange,
                    isUnlocked = pointsBalance.streakDays >= 3
                )
            }
        }

        // ==========================================
        // 5. App Version & Information Footer
        // ==========================================
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Yazen lingo Engine",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Black,
                color = Color(0xFFE2E8F0)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "الإصدار 1.0.0 • محرك تعليم اللغات التفاعلي",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF94A3B8)
            )
        }
    }
}

@Composable
fun ProfileStatCard(
    title: String,
    value: String,
    icon: ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF1E293B),
        modifier = modifier.border(1.5.dp, Color(0xFF334155), RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFCBD5E1)
            )
        }
    }
}

@Composable
private fun BadgeItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    isUnlocked: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(if (isUnlocked) iconColor.copy(alpha = 0.18f) else Color(0xFF334155)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isUnlocked) iconColor else Color(0xFF64748B),
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = if (isUnlocked) Color.White else Color(0xFF94A3B8)
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = if (isUnlocked) Color(0xFFCBD5E1) else Color(0xFF64748B),
                fontSize = 12.sp
            )
        }
        if (isUnlocked) {
            Text(
                text = "✓",
                fontWeight = FontWeight.Black,
                color = LingoGreen,
                fontSize = 18.sp
            )
        }
    }
}

/**
 * Authentic Google Sign-in button with genuine Google branding and high-contrast styling.
 */
@Composable
fun GoogleSignInButton(
    isSignedIn: Boolean,
    userEmail: String,
    onSignInClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        shadowElevation = 4.dp,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .clickable { onSignInClick() }
            .testTag("profile_google_sign_in_button")
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Google G emblem
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "G",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF4285F4)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = "تسجيل الدخول باستخدام Google",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Black,
                color = Color(0xFF1F2937),
                fontSize = 15.sp
            )
        }
    }
}
