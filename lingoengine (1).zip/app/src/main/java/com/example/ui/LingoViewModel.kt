package com.example.ui

import androidx.lifecycle.ViewModel
import com.example.data.ExerciseRepository
import com.example.data.LanguageCourse
import com.example.data.LearningPathRepository
import com.example.model.EngineStepResponse
import com.example.model.ExerciseItem
import com.example.model.LessonNode
import com.example.model.LessonNodeStatus
import com.example.model.MainNavTab
import com.example.model.PointsBalance
import com.example.model.QuestionType
import com.example.model.StepSubmissionState
import com.example.model.UnitData
import com.example.ui.components.GoogleAccountInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class LingoUiState(
    val courses: List<LanguageCourse> = ExerciseRepository.courses,
    val currentCourse: LanguageCourse = ExerciseRepository.courses.first(),
    val units: List<UnitData> = LearningPathRepository.getUnitsForCourse(ExerciseRepository.courses.first().id),
    val currentLesson: LessonNode? = null,
    val currentLessonExercises: List<ExerciseItem> = emptyList(),
    val currentTab: MainNavTab = MainNavTab.LEARN,
    val isInActiveExerciseSession: Boolean = false,
    val currentExerciseIndex: Int = 0,
    val selectedOption: String? = null,
    val arrangedWords: List<String> = emptyList(),
    val availableWords: List<String> = emptyList(),
    val submissionState: StepSubmissionState = StepSubmissionState.Unanswered,
    val pointsBalance: PointsBalance = PointsBalance(heartsRemaining = 5, totalXp = 0, streakDays = 3),
    val correctCount: Int = 0,
    val wrongCount: Int = 0,
    val isLessonCompleted: Boolean = false,
    val showJsonInspector: Boolean = false,
    val showCourseSelector: Boolean = false,
    val showOutOfHeartsDialog: Boolean = false,
    val isGoogleSignedIn: Boolean = false,
    val userGoogleEmail: String = "y9035528@gmail.com",
    val userGoogleName: String = "Yousef",
    val showGoogleAccountChooser: Boolean = false,
    val engineResponse: EngineStepResponse? = null,
    val jsonEngineOutput: String = ""
) {
    val totalQuestionsInSession: Int
        get() = if (currentLessonExercises.isNotEmpty()) currentLessonExercises.size else currentCourse.exercises.size

    val currentExercise: ExerciseItem?
        get() = if (currentLessonExercises.isNotEmpty()) {
            currentLessonExercises.getOrNull(currentExerciseIndex)
        } else {
            currentCourse.exercises.getOrNull(currentExerciseIndex)
        }

    val progress: Float
        get() = if (totalQuestionsInSession > 0) {
            (currentExerciseIndex.toFloat()) / totalQuestionsInSession.toFloat()
        } else 0f

    val canCheckAnswer: Boolean
        get() = when (currentExercise?.type) {
            QuestionType.WORD_ARRANGE -> arrangedWords.isNotEmpty()
            else -> !selectedOption.isNullOrBlank()
        }
}

class LingoViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(LingoUiState())
    val uiState: StateFlow<LingoUiState> = _uiState.asStateFlow()

    init {
        loadCourse(ExerciseRepository.courses.first())
    }

    fun selectCourse(course: LanguageCourse) {
        loadCourse(course)
    }

    private fun loadCourse(course: LanguageCourse) {
        val initialExercises = ExerciseRepository.getExercisesForLesson(course.id, null)
        val firstExercise = initialExercises.firstOrNull() ?: course.exercises.firstOrNull()
        val initialWords = if (firstExercise?.type == QuestionType.WORD_ARRANGE) {
            firstExercise.options.shuffled()
        } else {
            emptyList()
        }

        val totalSteps = initialExercises.ifEmpty { course.exercises }.size
        val initialEngineResponse = firstExercise?.let { item ->
            EngineStepResponse(
                step = 1,
                totalSteps = totalSteps,
                questionType = item.type.rawValue,
                targetLanguage = item.targetLanguage,
                targetText = item.targetText,
                instruction = item.instruction,
                options = item.options,
                correctAnswer = item.correctAnswer,
                userAnswer = null,
                isCorrect = null,
                explanation = null,
                pointsBalance = _uiState.value.pointsBalance.copy(earnedXpThisStep = 0)
            )
        }

        _uiState.update { current ->
            current.copy(
                currentCourse = course,
                units = LearningPathRepository.getUnitsForCourse(course.id),
                currentLesson = null,
                currentLessonExercises = initialExercises,
                currentExerciseIndex = 0,
                selectedOption = null,
                arrangedWords = emptyList(),
                availableWords = initialWords,
                submissionState = StepSubmissionState.Unanswered,
                correctCount = 0,
                wrongCount = 0,
                isLessonCompleted = false,
                showCourseSelector = false,
                showOutOfHeartsDialog = false,
                engineResponse = initialEngineResponse,
                jsonEngineOutput = initialEngineResponse?.toJsonString().orEmpty()
            )
        }
    }

    fun selectOption(option: String) {
        val state = _uiState.value
        if (state.submissionState !is StepSubmissionState.Unanswered &&
            state.submissionState !is StepSubmissionState.Selected
        ) return

        _uiState.update { current ->
            current.copy(
                selectedOption = option,
                submissionState = StepSubmissionState.Selected(option)
            )
        }
    }

    fun addWordToArranged(word: String, indexInAvailable: Int) {
        val state = _uiState.value
        if (state.submissionState !is StepSubmissionState.Unanswered &&
            state.submissionState !is StepSubmissionState.Selected
        ) return

        val newAvailable = state.availableWords.toMutableList()
        if (indexInAvailable in newAvailable.indices) {
            newAvailable.removeAt(indexInAvailable)
        }
        val newArranged = state.arrangedWords + word

        _uiState.update { current ->
            current.copy(
                arrangedWords = newArranged,
                availableWords = newAvailable,
                submissionState = if (newArranged.isNotEmpty()) {
                    StepSubmissionState.Selected(newArranged.joinToString(" "))
                } else {
                    StepSubmissionState.Unanswered
                }
            )
        }
    }

    fun removeWordFromArranged(word: String, indexInArranged: Int) {
        val state = _uiState.value
        if (state.submissionState !is StepSubmissionState.Unanswered &&
            state.submissionState !is StepSubmissionState.Selected
        ) return

        val newArranged = state.arrangedWords.toMutableList()
        if (indexInArranged in newArranged.indices) {
            newArranged.removeAt(indexInArranged)
        }
        val newAvailable = state.availableWords + word

        _uiState.update { current ->
            current.copy(
                arrangedWords = newArranged,
                availableWords = newAvailable,
                submissionState = if (newArranged.isNotEmpty()) {
                    StepSubmissionState.Selected(newArranged.joinToString(" "))
                } else {
                    StepSubmissionState.Unanswered
                }
            )
        }
    }

    fun submitAnswer(onResult: (isCorrect: Boolean) -> Unit) {
        val state = _uiState.value
        val exercise = state.currentExercise ?: return

        val userAnswer = when (exercise.type) {
            QuestionType.WORD_ARRANGE -> state.arrangedWords.joinToString(" ").trim()
            else -> state.selectedOption?.trim().orEmpty()
        }

        if (userAnswer.isBlank()) return

        val isCorrect = normalizeAnswer(userAnswer) == normalizeAnswer(exercise.correctAnswer)

        if (isCorrect) {
            val newTotalXp = state.pointsBalance.totalXp + exercise.xpReward
            val updatedBalance = state.pointsBalance.copy(
                earnedXpThisStep = exercise.xpReward,
                totalXp = newTotalXp
            )

            val updatedEngineResponse = EngineStepResponse(
                step = state.currentExerciseIndex + 1,
                totalSteps = state.totalQuestionsInSession,
                questionType = exercise.type.rawValue,
                targetLanguage = exercise.targetLanguage,
                targetText = exercise.targetText,
                instruction = exercise.instruction,
                options = exercise.options,
                correctAnswer = exercise.correctAnswer,
                userAnswer = userAnswer,
                isCorrect = true,
                explanation = exercise.explanation,
                pointsBalance = updatedBalance
            )

            _uiState.update { current ->
                current.copy(
                    submissionState = StepSubmissionState.EvaluatedCorrect(
                        answer = userAnswer,
                        xpEarned = exercise.xpReward,
                        explanation = exercise.explanation
                    ),
                    pointsBalance = updatedBalance,
                    correctCount = current.correctCount + 1,
                    engineResponse = updatedEngineResponse,
                    jsonEngineOutput = updatedEngineResponse.toJsonString()
                )
            }
            onResult(true)
        } else {
            val newHearts = (state.pointsBalance.heartsRemaining - 1).coerceAtLeast(0)
            val updatedBalance = state.pointsBalance.copy(
                earnedXpThisStep = 0,
                heartsRemaining = newHearts
            )

            val updatedEngineResponse = EngineStepResponse(
                step = state.currentExerciseIndex + 1,
                totalSteps = state.totalQuestionsInSession,
                questionType = exercise.type.rawValue,
                targetLanguage = exercise.targetLanguage,
                targetText = exercise.targetText,
                instruction = exercise.instruction,
                options = exercise.options,
                correctAnswer = exercise.correctAnswer,
                userAnswer = userAnswer,
                isCorrect = false,
                explanation = exercise.explanation,
                pointsBalance = updatedBalance
            )

            _uiState.update { current ->
                current.copy(
                    submissionState = StepSubmissionState.EvaluatedWrong(
                        answer = userAnswer,
                        correctAnswer = exercise.correctAnswer,
                        explanation = exercise.explanation
                    ),
                    pointsBalance = updatedBalance,
                    wrongCount = current.wrongCount + 1,
                    showOutOfHeartsDialog = newHearts == 0,
                    engineResponse = updatedEngineResponse,
                    jsonEngineOutput = updatedEngineResponse.toJsonString()
                )
            }
            onResult(false)
        }
    }

    fun nextStep() {
        val state = _uiState.value
        val nextIndex = state.currentExerciseIndex + 1
        val exercisesList = if (state.currentLessonExercises.isNotEmpty()) state.currentLessonExercises else state.currentCourse.exercises

        if (nextIndex >= exercisesList.size) {
            val completedLessonId = state.currentLesson?.id
            val currentUnitNum = state.currentLesson?.unitNumber ?: 1

            // Strictly unlock the next sequential lesson node in the unit (or stage 11 treasure chest)
            val updatedUnits = state.units.map { unit ->
                if (unit.unitNumber == currentUnitNum) {
                    val lessonList = unit.lessons
                    val completedIdx = lessonList.indexOfFirst { it.id == completedLessonId }
                    val updatedLessons = lessonList.mapIndexed { idx, node ->
                        when {
                            node.id == completedLessonId -> {
                                node.copy(
                                    status = LessonNodeStatus.COMPLETED,
                                    completedSteps = node.totalSteps
                                )
                            }
                            idx == completedIdx + 1 && node.status == LessonNodeStatus.LOCKED -> {
                                node.copy(status = LessonNodeStatus.CURRENT)
                            }
                            else -> node
                        }
                    }
                    unit.copy(lessons = updatedLessons)
                } else {
                    unit
                }
            }

            _uiState.update { current ->
                current.copy(
                    isLessonCompleted = true,
                    units = updatedUnits
                )
            }
            return
        }

        val nextExercise = exercisesList[nextIndex]
        val nextAvailableWords = if (nextExercise.type == QuestionType.WORD_ARRANGE) {
            nextExercise.options.shuffled()
        } else {
            emptyList()
        }

        val nextEngineResponse = EngineStepResponse(
            step = nextIndex + 1,
            totalSteps = exercisesList.size,
            questionType = nextExercise.type.rawValue,
            targetLanguage = nextExercise.targetLanguage,
            targetText = nextExercise.targetText,
            instruction = nextExercise.instruction,
            options = nextExercise.options,
            correctAnswer = nextExercise.correctAnswer,
            userAnswer = null,
            isCorrect = null,
            explanation = null,
            pointsBalance = state.pointsBalance.copy(earnedXpThisStep = 0)
        )

        _uiState.update { current ->
            current.copy(
                currentExerciseIndex = nextIndex,
                selectedOption = null,
                arrangedWords = emptyList(),
                availableWords = nextAvailableWords,
                submissionState = StepSubmissionState.Unanswered,
                engineResponse = nextEngineResponse,
                jsonEngineOutput = nextEngineResponse.toJsonString()
            )
        }
    }

    fun selectTab(tab: MainNavTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    /**
     * Starts a dedicated, non-repeating lesson session tailored to the chosen lesson node.
     */
    fun startLesson(lesson: LessonNode? = null) {
        val course = _uiState.value.currentCourse
        val lessonExercises = ExerciseRepository.getExercisesForLesson(course.id, lesson?.id)
        val firstExercise = lessonExercises.firstOrNull() ?: course.exercises.firstOrNull()

        val initialWords = if (firstExercise?.type == QuestionType.WORD_ARRANGE) {
            firstExercise.options.shuffled()
        } else {
            emptyList()
        }

        val totalSteps = lessonExercises.size
        val initialEngineResponse = firstExercise?.let { item ->
            EngineStepResponse(
                step = 1,
                totalSteps = totalSteps,
                questionType = item.type.rawValue,
                targetLanguage = item.targetLanguage,
                targetText = item.targetText,
                instruction = item.instruction,
                options = item.options,
                correctAnswer = item.correctAnswer,
                userAnswer = null,
                isCorrect = null,
                explanation = null,
                pointsBalance = _uiState.value.pointsBalance.copy(earnedXpThisStep = 0)
            )
        }

        _uiState.update { current ->
            current.copy(
                isInActiveExerciseSession = true,
                currentLesson = lesson,
                currentLessonExercises = lessonExercises,
                currentExerciseIndex = 0,
                selectedOption = null,
                arrangedWords = emptyList(),
                availableWords = initialWords,
                submissionState = StepSubmissionState.Unanswered,
                correctCount = 0,
                wrongCount = 0,
                isLessonCompleted = false,
                engineResponse = initialEngineResponse,
                jsonEngineOutput = initialEngineResponse?.toJsonString().orEmpty()
            )
        }
    }

    fun exitLessonSession() {
        _uiState.update { current ->
            current.copy(
                isInActiveExerciseSession = false,
                isLessonCompleted = false
            )
        }
    }

    fun refillHearts() {
        _uiState.update { current ->
            current.copy(
                pointsBalance = current.pointsBalance.copy(heartsRemaining = 5),
                showOutOfHeartsDialog = false
            )
        }
    }

    /**
     * Claims the 100 XP + 25 Gems reward from the unit's 11th Treasure Chest stage,
     * marks unit as completed, and unlocks the next unit in sequence.
     */
    fun claimTreasureChest(unitNumber: Int) {
        val state = _uiState.value
        val updatedBalance = state.pointsBalance.copy(
            totalXp = state.pointsBalance.totalXp + 100,
            gems = state.pointsBalance.gems + 25,
            earnedXpThisStep = 100
        )

        val updatedUnits = state.units.map { unit ->
            when (unit.unitNumber) {
                unitNumber -> {
                    val updatedLessons = unit.lessons.map { lesson ->
                        if (lesson.isTreasureChest) {
                            lesson.copy(
                                isChestClaimed = true,
                                status = LessonNodeStatus.COMPLETED
                            )
                        } else {
                            lesson
                        }
                    }
                    unit.copy(isCompleted = true, lessons = updatedLessons)
                }
                unitNumber + 1 -> {
                    val updatedLessons = unit.lessons.mapIndexed { idx, lesson ->
                        if (idx == 0 && lesson.status == LessonNodeStatus.LOCKED) {
                            lesson.copy(status = LessonNodeStatus.CURRENT)
                        } else {
                            lesson
                        }
                    }
                    unit.copy(isUnlocked = true, lessons = updatedLessons)
                }
                else -> unit
            }
        }

        _uiState.update { current ->
            current.copy(
                pointsBalance = updatedBalance,
                units = updatedUnits
            )
        }
    }

    fun restartLesson() {
        startLesson(_uiState.value.currentLesson)
    }

    fun toggleJsonInspector(visible: Boolean) {
        _uiState.update { it.copy(showJsonInspector = visible) }
    }

    fun toggleCourseSelector(visible: Boolean) {
        _uiState.update { it.copy(showCourseSelector = visible) }
    }

    fun openGoogleAccountChooser() {
        _uiState.update { it.copy(showGoogleAccountChooser = true) }
    }

    fun closeGoogleAccountChooser() {
        _uiState.update { it.copy(showGoogleAccountChooser = false) }
    }

    fun signInWithGoogleAccount(account: GoogleAccountInfo) {
        _uiState.update { current ->
            current.copy(
                isGoogleSignedIn = true,
                userGoogleEmail = account.email,
                userGoogleName = account.displayName,
                showGoogleAccountChooser = false
            )
        }
    }

    fun signOutGoogle() {
        _uiState.update { current ->
            current.copy(
                isGoogleSignedIn = false,
                showGoogleAccountChooser = false
            )
        }
    }

    fun toggleGoogleSignIn() {
        openGoogleAccountChooser()
    }

    private fun normalizeAnswer(input: String): String {
        return input.trim()
            .replace("[\\.,!؟?\\-]".toRegex(), "")
            .replace("\\s+".toRegex(), " ")
            .lowercase()
    }
}
