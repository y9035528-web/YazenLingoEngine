package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MainNavTab
import com.example.ui.theme.LingoBlue
import com.example.ui.theme.LingoCardBorder
import com.example.ui.theme.LingoGreen

@Composable
fun DuolingoBottomNavigation(
    selectedTab: MainNavTab,
    onTabSelected: (MainNavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFF0F172A),
        shadowElevation = 16.dp,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF334155))
            .testTag("duolingo_bottom_nav")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavItem(
                tab = MainNavTab.LEARN,
                selected = selectedTab == MainNavTab.LEARN,
                iconFilled = Icons.Filled.Home,
                iconOutlined = Icons.Outlined.Home,
                activeColor = LingoGreen,
                onClick = { onTabSelected(MainNavTab.LEARN) }
            )

            NavItem(
                tab = MainNavTab.PRACTICE,
                selected = selectedTab == MainNavTab.PRACTICE,
                iconFilled = Icons.Filled.FitnessCenter,
                iconOutlined = Icons.Outlined.FitnessCenter,
                activeColor = LingoBlue,
                onClick = { onTabSelected(MainNavTab.PRACTICE) }
            )

            NavItem(
                tab = MainNavTab.LEADERBOARD,
                selected = selectedTab == MainNavTab.LEADERBOARD,
                iconFilled = Icons.Filled.EmojiEvents,
                iconOutlined = Icons.Outlined.EmojiEvents,
                activeColor = Color(0xFFFFC800),
                onClick = { onTabSelected(MainNavTab.LEADERBOARD) }
            )

            NavItem(
                tab = MainNavTab.PROFILE,
                selected = selectedTab == MainNavTab.PROFILE,
                iconFilled = Icons.Filled.Person,
                iconOutlined = Icons.Outlined.Person,
                activeColor = Color(0xFF38BDF8),
                onClick = { onTabSelected(MainNavTab.PROFILE) }
            )
        }
    }
}

@Composable
private fun NavItem(
    tab: MainNavTab,
    selected: Boolean,
    iconFilled: ImageVector,
    iconOutlined: ImageVector,
    activeColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .testTag("nav_tab_${tab.name.lowercase()}")
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(if (selected) activeColor.copy(alpha = 0.22f) else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (selected) iconFilled else iconOutlined,
                contentDescription = tab.titleArabic,
                tint = if (selected) activeColor else Color(0xFF94A3B8),
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = tab.titleArabic,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
            color = if (selected) Color.White else Color(0xFF94A3B8),
            fontSize = 12.sp
        )
    }
}
