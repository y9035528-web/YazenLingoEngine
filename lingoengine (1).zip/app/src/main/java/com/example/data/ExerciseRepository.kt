package com.example.data

import com.example.model.ExerciseItem
import com.example.model.QuestionType

data class LanguageCourse(
    val id: String,
    val titleArabic: String,
    val titleEnglish: String,
    val flagEmoji: String,
    val languageCode: String,
    val defaultLocale: String,
    val exercises: List<ExerciseItem>
)

object ExerciseRepository {

    /**
     * Returns tailored, non-repeating exercises for a specific lesson node.
     * If lessonId is null (e.g. general practice), returns a fresh diverse mixture.
     */
    fun getExercisesForLesson(courseId: String, lessonId: String?): List<ExerciseItem> {
        val courseExercises = when (courseId.lowercase()) {
            "spanish" -> spanishLessonBank[lessonId] ?: spanishDefaultExercises
            "french" -> frenchLessonBank[lessonId] ?: frenchDefaultExercises
            "german" -> germanLessonBank[lessonId] ?: germanDefaultExercises
            else -> englishLessonBank[lessonId] ?: englishDefaultExercises
        }
        return courseExercises
    }

    // =========================================================================
    // ENGLISH QUESTION BANK (Organized by Unit & Lesson Node)
    // =========================================================================

    private val englishLessonBank: Map<String, List<ExerciseItem>> = mapOf(
        // Unit 1 - Lesson 1: التحيات اليومية (Daily Greetings)
        "u1_l1" to listOf(
            ExerciseItem(
                id = "en_u1_l1_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Good morning, friend!",
                phonetic = "ɡʊd ˈmɔːnɪŋ frend",
                instruction = "استمع للجملة الصوتية واختر الترجمة الصحيحة:",
                options = listOf(
                    "صباح الخير يا صديقي!",
                    "مساء الخير إلى اللقاء!",
                    "تصبح على خير ونوماً هنيئاً",
                    "أهلاً بك في منزلي"
                ),
                correctAnswer = "صباح الخير يا صديقي!",
                explanation = "عبارة 'Good morning' تعني 'صباح الخير'، وكلمة 'friend' تعني 'صديق'.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l1_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Hello, nice to meet you.",
                phonetic = "həˈləʊ naɪs tuː miːt juː",
                instruction = "رتب الكلمات لتكوين الترجمة الصحيحة:",
                options = listOf("مرحباً", "سررت", "بلقائك", "جداً", "مع", "السلامة", "أراك"),
                correctAnswer = "مرحباً سررت بلقائك",
                explanation = "'Hello' = مرحباً، و'nice to meet you' = سررت بلقائك.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u1_l1_3",
                type = QuestionType.MULTIPLE_CHOICE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "How are you doing today?",
                phonetic = "haʊ ɑːr juː ˈduːɪŋ təˈdeɪ",
                instruction = "ما هو المعنى الصحيح لهذا السؤال؟",
                options = listOf(
                    "كيف حالك اليوم؟",
                    "إلى أين أنت ذاهب اليوم؟",
                    "ماذا تفعل الآن؟",
                    "من أين أنت قادم اليوم؟"
                ),
                correctAnswer = "كيف حالك اليوم؟",
                explanation = "'How are you doing?' تعبير شائع جداً للسؤال عن الحال، و'today' تعني 'اليوم'.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l1_4",
                type = QuestionType.FILL_BLANK,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Good ___! Hope you have a great day.",
                phonetic = "ɡʊd ˈmɔːnɪŋ həʊp juː hæv ə ɡreɪt deɪ",
                instruction = "اختر الكلمة المناسبة لإكمال التحية الصباحية:",
                options = listOf("morning", "night", "bad", "sleep"),
                correctAnswer = "morning",
                explanation = "تكتمل التحية الصباحية بـ 'Good morning'.",
                sentenceWithBlank = "Good [ ___ ]! Hope you have a great day.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l1_5",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Welcome to our class!",
                phonetic = "ˈwelkəm tuː ˈaʊər klɑːs",
                instruction = "استمع للنطق الصوتي وحدد المعنى:",
                options = listOf(
                    "أهلاً بكم في فصلنا الدراسي!",
                    "شكراً على حضوركم اليوم",
                    "متى يبدأ الدرس القادم؟",
                    "هل هذا مقعدي المخصص؟"
                ),
                correctAnswer = "أهلاً بكم في فصلنا الدراسي!",
                explanation = "'Welcome' ترحيب، و'to our class' تعني إلى فصلنا.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l1_6",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "I am very happy.",
                phonetic = "aɪ æm ˈveri ˈhæpi",
                instruction = "رتب الكلمات بالعربية:",
                options = listOf("أنا", "سعيد", "جداً", "اليوم", "حزين", "متعب", "هنا"),
                correctAnswer = "أنا سعيد جداً",
                explanation = "'I am' = أنا، 'very' = جداً، 'happy' = سعيد.",
                xpReward = 15
            )
        ),

        // Unit 1 - Lesson 2: المشروبات والطعام (Food & Drinks)
        "u1_l2" to listOf(
            ExerciseItem(
                id = "en_u1_l2_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "A cup of hot coffee, please.",
                phonetic = "ə kʌp ʌv hɒt ˈkɒfi pliːz",
                instruction = "استمع للمقطع الصوتي واختر الطلب الصحيح:",
                options = listOf(
                    "فنجان قهوة ساخنة، من فضلك.",
                    "كوب شاي مثلج مع سكر.",
                    "زجاجة ماء بارد لو سمحت.",
                    "عصير برتقال طازج رجاءً."
                ),
                correctAnswer = "فنجان قهوة ساخنة، من فضلك.",
                explanation = "'A cup of hot coffee' فنجان قهوة ساخنة، و'please' تعني من فضلك.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l2_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Do you want tea or water?",
                phonetic = "duː juː wɒnt tiː ɔːr ˈwɔːtər",
                instruction = "رتب الكلمات لتكوين السؤال بالعربية:",
                options = listOf("هل", "تريد", "الشاي", "أم", "الماء؟", "عصير", "حليب", "بارد"),
                correctAnswer = "هل تريد الشاي أم الماء؟",
                explanation = "'Do you want' = هل تريد، 'tea or water' = شاي أم ماء.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u1_l2_3",
                type = QuestionType.MULTIPLE_CHOICE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "The apple is fresh and sweet.",
                phonetic = "ði ˈæpl ɪz freʃ ænd swiːt",
                instruction = "ما المعنى الصحيح لهذه الجملة؟",
                options = listOf(
                    "التفاحة طازجة وحلوة المذاق.",
                    "البرتقالة حمضية ولذيذة.",
                    "الخبز ساخن ومقرمش.",
                    "القهوة سوداء ومرة."
                ),
                correctAnswer = "التفاحة طازجة وحلوة المذاق.",
                explanation = "'apple' تفاحة، 'fresh' طازجة، 'sweet' حلوة.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l2_4",
                type = QuestionType.FILL_BLANK,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "I drink pure ___ every morning.",
                phonetic = "aɪ drɪŋk pjʊər ˈwɔːtər ˈevri ˈmɔːnɪŋ",
                instruction = "اختر المشروب الصحي لملء الفراغ:",
                options = listOf("water", "oil", "salt", "bread"),
                correctAnswer = "water",
                explanation = "'water' هي الكلمة الصحيحة للمشروب (أشرب ماءً نقياً كل صباح).",
                sentenceWithBlank = "I drink pure [ ___ ] every morning.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l2_5",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Would you like some sugar?",
                phonetic = "wʊd juː laɪk sʌm ˈʃʊɡər",
                instruction = "استمع للصوت وحدد السؤال المطروح:",
                options = listOf(
                    "هل ترغب في بعض السكر؟",
                    "هل تريد وجبة خفيفة؟",
                    "أين أجد ملعقة صغيرة؟",
                    "هل المشروب بارد بما يكفي؟"
                ),
                correctAnswer = "هل ترغب في بعض السكر؟",
                explanation = "'Would you like' تعني هل ترغب في، و'sugar' تعني سكر.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l2_6",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Breakfast is ready now.",
                phonetic = "ˈbrekfəst ɪz ˈredi naʊ",
                instruction = "رتب كلمات الترجمة:",
                options = listOf("وجبة", "الفطور", "جاهزة", "الآن", "العشاء", "متأخر", "لذيذ"),
                correctAnswer = "وجبة الفطور جاهزة الآن",
                explanation = "'Breakfast' = وجبة الفطور، 'is ready' = جاهزة، 'now' = الآن.",
                xpReward = 15
            )
        ),

        // Unit 1 - Lesson 3: الأسئلة والضمائر (Questions & Pronouns)
        "u1_l3" to listOf(
            ExerciseItem(
                id = "en_u1_l3_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Where is the train station?",
                phonetic = "weər ɪz ðə treɪn ˈsteɪʃn",
                instruction = "استمع للسؤال واختر الترجمة الصحيحة:",
                options = listOf(
                    "أين محطة القطار؟",
                    "متى يصل القطار السريع؟",
                    "كم ثمن تذكرة القطار؟",
                    "أين موقف سيارات الأجرة؟"
                ),
                correctAnswer = "أين محطة القطار؟",
                explanation = "'Where is' تعني أين يكون، و'train station' تعني محطة القطار.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l3_2",
                type = QuestionType.MULTIPLE_CHOICE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Who is your English teacher?",
                phonetic = "huː ɪz jɔːr ˈɪŋɡlɪʃ ˈtiːtʃər",
                instruction = "اختر الترجمة الصحيحة لأداة الاستفهام 'Who':",
                options = listOf(
                    "من هو معلمك للغة الإنجليزية؟",
                    "أين يدرس معلم الإنجليزية؟",
                    "متى موعد حصة الإنجليزية؟",
                    "كيف تتدرب على الإنجليزية؟"
                ),
                correctAnswer = "من هو معلمك للغة الإنجليزية؟",
                explanation = "أداة الاستفهام 'Who' تسأل عن العاقل وتعني 'مَن'.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l3_3",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "She is reading a useful book.",
                phonetic = "ʃiː ɪz ˈriːdɪŋ ə ˈjuːsfl bʊk",
                instruction = "رتب الجملة بالترتيب السليم:",
                options = listOf("هي", "تقرأ", "كتاباً", "مفيداً", "هو", "يكتب", "جديد"),
                correctAnswer = "هي تقرأ كتاباً مفيداً",
                explanation = "'She' = هي، 'is reading' = تقرأ، 'a useful book' = كتاباً مفيداً.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u1_l3_4",
                type = QuestionType.FILL_BLANK,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "They ___ studying hard for the test.",
                phonetic = "ðeɪ ɑːr ˈstʌdiɪŋ hɑːd fɔːr ðə test",
                instruction = "اختر فعل الكينونة المناسب للضمير الجمع 'They':",
                options = listOf("are", "is", "am", "be"),
                correctAnswer = "are",
                explanation = "الضمير 'They' يأخذ الفعل 'are' في المضارع المستمر.",
                sentenceWithBlank = "They [ ___ ] studying hard for the test.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l3_5",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Why are you learning languages?",
                phonetic = "waɪ ɑːr juː ˈlɜːnɪŋ ˈlæŋɡwɪdʒɪz",
                instruction = "استمع واختر معنى السؤال:",
                options = listOf(
                    "لماذا تتعلم اللغات؟",
                    "ما هي لغتك الأم؟",
                    "أين تمارس التحدث باللغة؟",
                    "هل اللغة الإنجليزية صعبة؟"
                ),
                correctAnswer = "لماذا تتعلم اللغات؟",
                explanation = "'Why' للسؤال عن السبب (لماذا)، و'learning languages' تعلم اللغات.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l3_6",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "We can speak English.",
                phonetic = "wiː kæn spiːk ˈɪŋɡlɪʃ",
                instruction = "رتب الكلمات بالعربية:",
                options = listOf("نحن", "نستطيع", "التحدث", "باللغة", "الإنجليزية", "هم", "قراءة"),
                correctAnswer = "نحن نستطيع التحدث باللغة الإنجليزية",
                explanation = "'We can speak English' = نحن نستطيع التحدث بالإنجليزية.",
                xpReward = 15
            )
        ),

        // Unit 1 - Lesson 4: الوداع والشكر (Farewells & Gratitude)
        "u1_l4" to listOf(
            ExerciseItem(
                id = "en_u1_l4_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Thank you very much for your help!",
                phonetic = "θæŋk juː ˈveri mʌtʃ fɔːr jɔːr help",
                instruction = "استمع لعبارة الشكر واختر الترجمة المتقنة:",
                options = listOf(
                    "شكراً جزيلاً لك على مساعدتك!",
                    "عفواً لا شكر على واجب أبداً",
                    "أرجو أن تعود لزيارتنا قريباً",
                    "هل تحتاج لأي مساعدة إضافية؟"
                ),
                correctAnswer = "شكراً جزيلاً لك على مساعدتك!",
                explanation = "'Thank you very much' شكراً جزيلاً، 'for your help' على مساعدتك.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l4_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Have a safe trip home.",
                phonetic = "hæv ə seɪf trɪp həʊm",
                instruction = "رتب كلمات التمني بالسلامة:",
                options = listOf("أتمنى", "لك", "رحلة", "آمنة", "إلى", "المنزل", "سفر", "سعيد"),
                correctAnswer = "أتمنى لك رحلة آمنة إلى المنزل",
                explanation = "'Have a safe trip' رحلة آمنة، 'home' إلى المنزل.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u1_l4_3",
                type = QuestionType.MULTIPLE_CHOICE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "You are always welcome here.",
                phonetic = "juː ɑːr ˈɔːlweɪz ˈwelkəm hɪər",
                instruction = "ما المقصود بهذه العبارة الترحيبية والمهذبة؟",
                options = listOf(
                    "مرحب بك دائماً هنا.",
                    "شكراً لك على هذا الاستقبال.",
                    "إلى اللقاء في الأسبوع القادم.",
                    "هل يمكنك العودة غداً صباحاً؟"
                ),
                correctAnswer = "مرحب بك دائماً هنا.",
                explanation = "'You are always welcome' مرحب بك على الدوام، 'here' هنا.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l4_4",
                type = QuestionType.FILL_BLANK,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "See ___ tomorrow afternoon!",
                phonetic = "siː juː təˈmɒrəʊ ˌɑːftəˈnuːn",
                instruction = "اختر الضمير لإكمال عبارة الوداع الشهيرة:",
                options = listOf("you", "they", "we", "he"),
                correctAnswer = "you",
                explanation = "عبارة الوداع 'See you tomorrow' (أراك غداً).",
                sentenceWithBlank = "See [ ___ ] tomorrow afternoon!",
                xpReward = 10
            ),
            ExerciseItem(
                id = "en_u1_l4_5",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Take good care of yourself!",
                phonetic = "teɪk ɡʊd keər ʌv jɔːˈself",
                instruction = "استمع للنصيحة الوداعية وحدد معناها:",
                options = listOf(
                    "اعتنِ بنفسك جيداً!",
                    "لا تنسَ موعدنا القادم",
                    "اتصل بي عند وصولك",
                    "أتمنى لك الشفاء العاجل"
                ),
                correctAnswer = "اعتنِ بنفسك جيداً!",
                explanation = "'Take care of yourself' تعني اعتنِ بنفسك.",
                xpReward = 10
            )
        ),

        // Unit 1 - Lesson 5: اختبار ختام الوحدة (Unit Trophy Exam)
        "u1_l5" to listOf(
            ExerciseItem(
                id = "en_u1_l5_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Welcome to our language academy!",
                phonetic = "ˈwelkəm tuː ˈaʊər ˈlæŋɡwɪdʒ əˈkædəmi",
                instruction = "اختبار الكأس 🏆: استمع بدقة للجملة الصوتية:",
                options = listOf(
                    "أهلاً بكم في أكاديميتنا لتعليم اللغات!",
                    "شكراً لاشتراككم في الدورة المتقدمة",
                    "متى تبدأ الاختبارات النهائية للوحدة؟",
                    "كيف تسجل في برنامج تبادل اللغات؟"
                ),
                correctAnswer = "أهلاً بكم في أكاديميتنا لتعليم اللغات!",
                explanation = "'Welcome' ترحيب، 'language academy' أكاديمية اللغات.",
                xpReward = 20
            ),
            ExerciseItem(
                id = "en_u1_l5_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Practice makes progress every single day.",
                phonetic = "ˈpræktɪs meɪks ˈprəʊɡres ˈevri ˈsɪŋɡl deɪ",
                instruction = "رتب الحكمة الإنجليزية المترجمة:",
                options = listOf("التدريب", "يصنع", "التقدم", "في", "كل", "يوم", "النجاح", "دائماً"),
                correctAnswer = "التدريب يصنع التقدم في كل يوم",
                explanation = "'Practice makes progress' ممارسة وتدريب يحقق التقدم، 'every single day' كل يوم.",
                xpReward = 25
            ),
            ExerciseItem(
                id = "en_u1_l5_3",
                type = QuestionType.FILL_BLANK,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "She always ___ fresh orange juice.",
                phonetic = "ʃiː ˈɔːlweɪz drɪŋks freʃ ˈɒrɪndʒ dʒuːs",
                instruction = "اختر الفعل المناسب للمضارع البسيط مع (She):",
                options = listOf("drinks", "drink", "drinking", "drank"),
                correctAnswer = "drinks",
                explanation = "مع الضمير المفرد She في المضارع البسيط نضع 's' للفعل: drinks.",
                sentenceWithBlank = "She always [ ___ ] fresh orange juice.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u1_l5_4",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Can you repeat the question slowly, please?",
                phonetic = "kæn juː rɪˈpiːt ðə ˈkwestʃən ˈsləʊli pliːz",
                instruction = "استمع للطلب المهذب وحدد معناه:",
                options = listOf(
                    "هل يمكنك تكرار السؤال ببطء، من فضلك؟",
                    "هل تفهم ما أقوله الآن بشكل جيد؟",
                    "أين أجد الإجابة النموذجية في الكتاب؟",
                    "متى ينتهي وقت هذا الاختبار التجريبي؟"
                ),
                correctAnswer = "هل يمكنك تكرار السؤال ببطء، من فضلك؟",
                explanation = "'repeat' كرر، 'slowly' ببطء، 'question' السؤال.",
                xpReward = 20
            ),
            ExerciseItem(
                id = "en_u1_l5_5",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "I am proud of my progress.",
                phonetic = "aɪ æm praʊd ʌv maɪ ˈprəʊɡres",
                instruction = "رتب كلمات الإنجاز:",
                options = listOf("أنا", "فخور", "بتقدمي", "في", "التعلم", "سعيد", "جداً"),
                correctAnswer = "أنا فخور بتقدمي في التعلم",
                explanation = "'proud of' = فخور بـ، 'my progress' = تقدمي وإنجازي.",
                xpReward = 20
            )
        ),

        // Unit 2 - Lesson 1: طلب الوجبات (Ordering Meals)
        "u2_l1" to listOf(
            ExerciseItem(
                id = "en_u2_l1_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "May I see the dinner menu, please?",
                phonetic = "meɪ aɪ siː ðə ˈdɪnər ˈmenjuː pliːz",
                instruction = "استمع لطلب الزبون في المطعم واختر الترجمة:",
                options = listOf(
                    "هل يمكنني رؤية قائمة طعام العشاء، من فضلك؟",
                    "هل هذا الطبق يحتوي على مكونات حارة؟",
                    "كم من الوقت يستغرق إعداد هذه الوجبة؟",
                    "هل يمكننا الحصول على طاولة بجوار النافذة؟"
                ),
                correctAnswer = "هل يمكنني رؤية قائمة طعام العشاء، من فضلك؟",
                explanation = "'May I see' طلب مهذب برؤية، 'dinner menu' قائمة العشاء.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l1_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "I would like the grilled chicken.",
                phonetic = "aɪ wʊd laɪk ðə ɡrɪld ˈtʃɪkɪn",
                instruction = "رتب الكلمات لطلب الوجبة بالعربية:",
                options = listOf("أود", "طلب", "الدجاج", "المشوي", "لحم", "سلطة", "أرز"),
                correctAnswer = "أود طلب الدجاج المشوي",
                explanation = "'I would like' = أود، 'the grilled chicken' = الدجاج المشوي.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l1_3",
                type = QuestionType.MULTIPLE_CHOICE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Could we have the bill, please?",
                phonetic = "kʊd wiː hæv ðə bɪl pliːz",
                instruction = "ما الذي يطلبه الزبون في نهاية الوجبة؟",
                options = listOf(
                    "الحساب / الفاتورة، لو سمحت.",
                    "كوب ماء إضافي، من فضلك.",
                    "قائمة الحلويات والمشروبات.",
                    "تغليف باقي الطعام لأخذه معنا."
                ),
                correctAnswer = "الحساب / الفاتورة، لو سمحت.",
                explanation = "'the bill' هي فاتورة المطعم أو الحساب.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l1_4",
                type = QuestionType.FILL_BLANK,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "This hot soup is very ___ and tasty.",
                phonetic = "ðɪs hɒt suːp ɪz ˈveri dɪˈlɪʃəs ænd ˈteɪsti",
                instruction = "اختر الصفة المناسبة للطعام اللذيذ:",
                options = listOf("delicious", "cold", "broken", "empty"),
                correctAnswer = "delicious",
                explanation = "'delicious' تعني لذيذ وشهي وتناسب وصف الحساء.",
                sentenceWithBlank = "This hot soup is very [ ___ ] and tasty.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l1_5",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Enjoy your meal!",
                phonetic = "ɪnˈdʒɔɪ jɔːr miːl",
                instruction = "استمع لعبارة النادل وتعرف على معناها:",
                options = listOf(
                    "بالهناء والشفاء! (استمتع بوجبتك)",
                    "هل انتهيت من تناول طعامك؟",
                    "شكراً لزيارتك مطعمنا اليوم",
                    "سأحضر لك كوب القهوة فوراً"
                ),
                correctAnswer = "بالهناء والشفاء! (استمتع بوجبتك)",
                explanation = "'Enjoy your meal' عبارة مشهورة تعني بالهناء والشفاء / شهية طيبة.",
                xpReward = 15
            )
        ),

        // Unit 2 - Lesson 2: الاتجاهات في المدينة (Directions in Town)
        "u2_l2" to listOf(
            ExerciseItem(
                id = "en_u2_l2_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Turn right at the traffic light.",
                phonetic = "tɜːn raɪt æt ðə ˈtræfɪk laɪt",
                instruction = "استمع لوصف الاتجاه واختر الترجمة الدقيقة:",
                options = listOf(
                    "انعطف يميناً عند إشارة المرور.",
                    "سر للأمام مباشرة حتى الدوار.",
                    "انعطف يساراً بعد محطة الوقود.",
                    "توقف هنا أمام المجمع التجاري."
                ),
                correctAnswer = "انعطف يميناً عند إشارة المرور.",
                explanation = "'Turn right' انعطف يميناً، 'traffic light' إشارة المرور.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l2_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Walk straight for two blocks.",
                phonetic = "wɔːk streɪt fɔːr tuː blɒks",
                instruction = "رتب تعليمات السير:",
                options = listOf("امشِ", "مباشرة", "لمسافة", "مربعين", "سكنيين", "ثم", "ارجع"),
                correctAnswer = "امشِ مباشرة لمسافة مربعين سكنيين",
                explanation = "'Walk straight' امشِ مستقيماً، 'two blocks' مبنيين أو مربعين سكنيين.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l2_3",
                type = QuestionType.MULTIPLE_CHOICE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "The central bank is on the left.",
                phonetic = "ðə ˈsentrəl bæŋk ɪz ɒn ðə left",
                instruction = "أين يقع البنك المركزي وفقاً للجملة؟",
                options = listOf(
                    "على جهة اليسار.",
                    "على جهة اليمين.",
                    "في نهاية الشارع تماماً.",
                    "خلف محطة الحافلات."
                ),
                correctAnswer = "على جهة اليسار.",
                explanation = "'on the left' تعني على جهة اليسار.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l2_4",
                type = QuestionType.FILL_BLANK,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Excuse me, how do I get to the ___?",
                phonetic = "ɪkˈskjuːs miː haʊ duː aɪ ɡet tuː ði ˈeəpɔːt",
                instruction = "اختر وجهة السفر لملء السؤال:",
                options = listOf("airport", "plate", "spoon", "shoe"),
                correctAnswer = "airport",
                explanation = "'airport' المطار وهي الوجهة المنطقية في السؤال.",
                sentenceWithBlank = "Excuse me, how do I get to the [ ___ ]?",
                xpReward = 15
            )
        ),

        // Unit 2 - Lesson 3: الفندق والحجز (Hotel & Reservations)
        "u2_l3" to listOf(
            ExerciseItem(
                id = "en_u2_l3_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "I have a room reservation for two nights.",
                phonetic = "aɪ hæv ə ruːm ˌrezəˈveɪʃn fɔːr tuː naɪts",
                instruction = "استمع لطلب النزيل في الفندق واختر الترجمة الصحيحة:",
                options = listOf(
                    "لديّ حجز لغرفة لمدة ليلتين.",
                    "هل لديكم غرف شاغرة تطل على البحر؟",
                    "أريد تأكيد موعد تسجيل المغادرة غداً.",
                    "كم تكلفة الليلة الواحدة لشخصين؟"
                ),
                correctAnswer = "لديّ حجز لغرفة لمدة ليلتين.",
                explanation = "'room reservation' حجز غرفة، 'for two nights' لمدة ليلتين.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l3_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Here is your electronic room key.",
                phonetic = "hɪər ɪz jɔːr ˌelekˈtrɒnɪk ruːm kiː",
                instruction = "رتب كلمات موظف الاستقبال:",
                options = listOf("تفضل", "مفتاح", "غرفتك", "الإلكتروني", "هنا", "حقيبتك", "جوازك"),
                correctAnswer = "تفضل مفتاح غرفتك الإلكتروني هنا",
                explanation = "'Here is' تفضل / إليك، 'your electronic room key' مفتاح غرفتك الإلكتروني.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l3_3",
                type = QuestionType.MULTIPLE_CHOICE,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "Is breakfast included in the reservation?",
                phonetic = "ɪz ˈbrekfəst ɪnˈkluːdɪd ɪn ðə ˌrezəˈveɪʃn",
                instruction = "ما الذي يستفسر عنه النزيل؟",
                options = listOf(
                    "هل وجبة الإفطار مشمولة في الحجز؟",
                    "في أي وقت يتم تقديم وجبة العشاء؟",
                    "هل تتوفر خدمة غسيل الملابس بالفندق؟",
                    "أين يمكنني ركن سيارتي بأمان؟"
                ),
                correctAnswer = "هل وجبة الإفطار مشمولة في الحجز؟",
                explanation = "'included' تعني مشمول أو متضمن، و'breakfast' وجبة الإفطار.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "en_u2_l3_4",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "English",
                languageCode = "en",
                targetText = "We hope you enjoy your stay with us.",
                phonetic = "wiː həʊp juː ɪnˈdʒɔɪ jɔːr steɪ wɪð ʌs",
                instruction = "استمع لعبارة موظف الفندق وحدد معناها:",
                options = listOf(
                    "نتمنى لك إقامة ممتعة معنا.",
                    "يسعدنا مساعدتك في حمل الأمتعة.",
                    "شكراً لاختيارك الإقامة في فندقنا.",
                    "هل تود الحصول على خريطة للمدينة؟"
                ),
                correctAnswer = "نتمنى لك إقامة ممتعة معنا.",
                explanation = "'enjoy your stay' استمتع بإقامتك.",
                xpReward = 15
            )
        )
    )

    // Fallback general exercises for English
    private val englishDefaultExercises = englishLessonBank.values.flatten()

    // =========================================================================
    // SPANISH BANK
    // =========================================================================
    private val spanishLessonBank: Map<String, List<ExerciseItem>> = mapOf(
        "u1_l1" to listOf(
            ExerciseItem(
                id = "es_u1_l1_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "Spanish",
                languageCode = "es",
                targetText = "¡Hola! ¿Cómo estás, amigo?",
                phonetic = "ola komo estas amiɣo",
                instruction = "استمع للتحية الإسبانية واختر المعنى الصحيح:",
                options = listOf(
                    "مرحباً! كيف حالك يا صديقي؟",
                    "صباح الخير! إلى أين تذهب الآن؟",
                    "مع السلامة وشكراً جزيلاً لك",
                    "تشرفت بلقائك وسررت برؤيتك"
                ),
                correctAnswer = "مرحباً! كيف حالك يا صديقي؟",
                explanation = "'¡Hola!' مرحباً، '¿Cómo estás?' كيف حالك، 'amigo' صديقي.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "es_u1_l1_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "Spanish",
                languageCode = "es",
                targetText = "Buenos días, mucho gusto.",
                phonetic = "bwenos di-as mutʃo ɣusto",
                instruction = "رتب كلمات التحية الإسبانية بالعربية:",
                options = listOf("صباح", "الخير", "تشرفت", "بلقائك", "مساء", "وداعاً", "شكراً"),
                correctAnswer = "صباح الخير تشرفت بلقائك",
                explanation = "'Buenos días' صباح الخير، 'mucho gusto' سررت بلقائك.",
                xpReward = 15
            ),
            ExerciseItem(
                id = "es_u1_l1_3",
                type = QuestionType.MULTIPLE_CHOICE,
                targetLanguage = "Spanish",
                languageCode = "es",
                targetText = "¿De dónde eres tú?",
                phonetic = "de ðonde eres tu",
                instruction = "ما معنى هذا السؤال بالإسبانية؟",
                options = listOf(
                    "من أين أنت؟",
                    "كم عمرك؟",
                    "أين تسكن الآن؟",
                    "ما هي مهنتك؟"
                ),
                correctAnswer = "من أين أنت؟",
                explanation = "'¿De dónde eres?' سؤال كلاسيكي عن بلد المنشأ والجنسية.",
                xpReward = 10
            )
        ),
        "u1_l2" to listOf(
            ExerciseItem(
                id = "es_u1_l2_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "Spanish",
                languageCode = "es",
                targetText = "Un café con leche, por favor.",
                phonetic = "un kafe kon letʃe por faβor",
                instruction = "استمع لطلب المقهى الإسباني وحدد معناه:",
                options = listOf(
                    "قهوة بالحليب، من فضلك.",
                    "كوب شاي بارد مع ليمون.",
                    "عصير برتقال طازج رجاءً.",
                    "زجاجة ماء معدني فوار."
                ),
                correctAnswer = "قهوة بالحليب، من فضلك.",
                explanation = "'café con leche' قهوة بالحليب، 'por favor' من فضلك.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "es_u1_l2_2",
                type = QuestionType.FILL_BLANK,
                targetLanguage = "Spanish",
                languageCode = "es",
                targetText = "Yo ___ agua todos los días.",
                phonetic = "ʝo beβo aɣwa toðos los di-as",
                instruction = "اختر تصريف الفعل 'beber' (يشرب) مع (Yo):",
                options = listOf("bebo", "bebes", "bebe", "bebemos"),
                correctAnswer = "bebo",
                explanation = "مع الضمير Yo ينتهي تصريف الفعل بالحرف o: bebo.",
                sentenceWithBlank = "Yo [ ___ ] agua todos los días.",
                xpReward = 10
            )
        )
    )
    private val spanishDefaultExercises = spanishLessonBank.values.flatten()

    // =========================================================================
    // FRENCH BANK
    // =========================================================================
    private val frenchLessonBank: Map<String, List<ExerciseItem>> = mapOf(
        "u1_l1" to listOf(
            ExerciseItem(
                id = "fr_u1_l1_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "French",
                languageCode = "fr",
                targetText = "Bonjour, enchanté de vous rencontrer !",
                phonetic = "bɔ̃ʒuʁ ɑ̃ʃɑ̃te də vu ʁɑ̃kɔ̃tʁe",
                instruction = "استمع للتحية الفرنسية الأنيقة واختر معناها:",
                options = listOf(
                    "مرحباً، تشرفت جداً بلقائكم!",
                    "مساء الخير، هل تتحدث الفرنسية؟",
                    "إلى اللقاء وأتمنى لك يوماً سعيداً",
                    "شكراً جزيلاً على هذه الهدية الجميلة"
                ),
                correctAnswer = "مرحباً، تشرفت جداً بلقائكم!",
                explanation = "'Bonjour' مرحباً، 'enchanté' سررت وتشرفت بلقائكم.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "fr_u1_l1_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "French",
                languageCode = "fr",
                targetText = "Je m'appelle Pierre.",
                phonetic = "ʒə ma-pɛl pjɛʁ",
                instruction = "رتب جملة التعريف بالاسم:",
                options = listOf("اسمي", "هو", "بيير", "طالب", "من", "باريس", "أنا"),
                correctAnswer = "اسمي هو بيير",
                explanation = "'Je m'appelle' تعني أدعى / اسمي هو.",
                xpReward = 15
            )
        ),
        "u1_l2" to listOf(
            ExerciseItem(
                id = "fr_u1_l2_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "French",
                languageCode = "fr",
                targetText = "Je voudrais un croissant et un café, s'il vous plaît.",
                phonetic = "ʒə vudʁɛ œ̃ kʁwasɑ̃ e œ̃ kafe sil vu plɛ",
                instruction = "استمع للطلب في المخبز الفرنسي:",
                options = listOf(
                    "أود كرواسون وفنجان قهوة، من فضلك.",
                    "شاي مثلج وقطعة كعك بالشوكولاتة.",
                    "أين أجد أقرب مخبز فرنسي تقليدي؟",
                    "الحساب لو سمحت مع الفاتورة."
                ),
                correctAnswer = "أود كرواسون وفنجان قهوة، من فضلك.",
                explanation = "'Je voudrais' أسلوب مهذب يعني أود، 'croissant et un café' كرواسون وقهوة.",
                xpReward = 10
            )
        )
    )
    private val frenchDefaultExercises = frenchLessonBank.values.flatten()

    // =========================================================================
    // GERMAN BANK
    // =========================================================================
    private val germanLessonBank: Map<String, List<ExerciseItem>> = mapOf(
        "u1_l1" to listOf(
            ExerciseItem(
                id = "de_u1_l1_1",
                type = QuestionType.LISTEN_SELECT,
                targetLanguage = "German",
                languageCode = "de",
                targetText = "Guten Morgen! Wie geht es dir?",
                phonetic = "ɡuːtn̩ ˈmɔʁɡn̩ viː ɡeːt ɛs diːɐ̯",
                instruction = "استمع للتحية الألمانية واختر المعنى الدقيق:",
                options = listOf(
                    "صباح الخير! كيف حالك؟",
                    "طاب مساؤك! إلى أين تذهب؟",
                    "تصبح على خير وأحلام سعيدة",
                    "شكراً جزيلاً على دعوتك الكريمة"
                ),
                correctAnswer = "صباح الخير! كيف حالك؟",
                explanation = "'Guten Morgen' صباح الخير، 'Wie geht es dir?' كيف حالك.",
                xpReward = 10
            ),
            ExerciseItem(
                id = "de_u1_l1_2",
                type = QuestionType.WORD_ARRANGE,
                targetLanguage = "German",
                languageCode = "de",
                targetText = "Ich lerne Deutsch jeden Tag.",
                phonetic = "ɪç ˈlɛʁnə dɔʏtʃ ˈjeːdn̩ taːk",
                instruction = "رتب كلمات الجملة الألمانية بالعربية:",
                options = listOf("أنا", "أتعلم", "الألمانية", "كل", "يوم", "كتاب", "هنا"),
                correctAnswer = "أنا أتعلم الألمانية كل يوم",
                explanation = "'Ich lerne Deutsch' أنا أتعلم الألمانية، 'jeden Tag' كل يوم.",
                xpReward = 15
            )
        )
    )
    private val germanDefaultExercises = germanLessonBank.values.flatten()

    val courses: List<LanguageCourse> = listOf(
        LanguageCourse(
            id = "english",
            titleArabic = "اللغة الإنجليزية",
            titleEnglish = "English",
            flagEmoji = "🇬🇧",
            languageCode = "English",
            defaultLocale = "en",
            exercises = englishDefaultExercises
        ),
        LanguageCourse(
            id = "spanish",
            titleArabic = "اللغة الإسبانية",
            titleEnglish = "Spanish",
            flagEmoji = "🇪🇸",
            languageCode = "Spanish",
            defaultLocale = "es",
            exercises = spanishDefaultExercises
        ),
        LanguageCourse(
            id = "french",
            titleArabic = "اللغة الفرنسية",
            titleEnglish = "French",
            flagEmoji = "🇫🇷",
            languageCode = "French",
            defaultLocale = "fr",
            exercises = frenchDefaultExercises
        ),
        LanguageCourse(
            id = "german",
            titleArabic = "اللغة الألمانية",
            titleEnglish = "German",
            flagEmoji = "🇩🇪",
            languageCode = "German",
            defaultLocale = "de",
            exercises = germanDefaultExercises
        )
    )
}
