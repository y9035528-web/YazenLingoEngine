package com.example.data

import com.example.model.LessonNode
import com.example.model.LessonNodeStatus
import com.example.model.UnitData

object LearningPathRepository {

    // Zig-zag offsets for 10 sequential stages + centered 11th treasure chest
    private val stageXOffsets = listOf(
        0.0f,   // Stage 1 (Center)
        0.55f,  // Stage 2 (Right)
        0.25f,  // Stage 3 (Mid-Right)
        -0.35f, // Stage 4 (Mid-Left)
        -0.65f, // Stage 5 (Left)
        -0.30f, // Stage 6 (Mid-Left)
        0.35f,  // Stage 7 (Mid-Right)
        0.65f,  // Stage 8 (Right)
        0.25f,  // Stage 9 (Mid-Right)
        0.0f,   // Stage 10 (Center - Boss/Trophy)
        0.0f    // Stage 11 (Center - Treasure Chest 🎁)
    )

    fun getUnitsForCourse(courseId: String): List<UnitData> {
        return listOf(
            createUnit1(),
            createUnit2(),
            createUnit3(),
            createUnit4(),
            createUnit5(),
            createUnit6(),
            createUnit7(),
            createUnit8(),
            createUnit9(),
            createUnit10()
        )
    }

    private fun createUnit1(): UnitData {
        val stageMeta = listOf(
            Triple("التحيات اليومية", "Hello, Good morning", "👋"),
            Triple("المشروبات والماء", "Coffee, Tea, Water", "☕"),
            Triple("الأسئلة والضمائر", "I am, You are, Where", "❓"),
            Triple("الوداع والشكر", "Goodbye, Thank you", "🙏"),
            Triple("الأرقام البسيطة", "One, Two, Three", "🔢"),
            Triple("الألوان الأساسية", "Red, Blue, Green", "🎨"),
            Triple("الطلب بلباقة", "Please, Excuse me", "✨"),
            Triple("الوصف والصفات", "Good, Big, Small", "🌟"),
            Triple("مراجعة المفردات", "Vocabulary Drill", "📝"),
            Triple("اختبار الوحدة الكبرى", "Unit 1 Mastery Exam", "🏆")
        )

        val lessons = stageMeta.mapIndexed { index, meta ->
            val stageNum = index + 1
            LessonNode(
                id = "u1_l$stageNum",
                unitNumber = 1,
                stageNumber = stageNum,
                title = meta.first,
                subtitle = meta.second,
                iconEmoji = meta.third,
                totalSteps = if (stageNum == 10) 8 else 5,
                completedSteps = if (stageNum == 1) 0 else 0,
                status = if (stageNum == 1) LessonNodeStatus.CURRENT else LessonNodeStatus.LOCKED,
                xOffsetFactor = stageXOffsets[index],
                isTreasureChest = false,
                isChestClaimed = false
            )
        }.toMutableList()

        // 11th stage: Treasure Chest
        lessons.add(
            LessonNode(
                id = "u1_chest",
                unitNumber = 1,
                stageNumber = 11,
                title = "صندوق كنز الوحدة 1",
                subtitle = "100 XP + 25 جوهرة 💎",
                iconEmoji = "🎁",
                totalSteps = 1,
                completedSteps = 0,
                status = LessonNodeStatus.LOCKED,
                xOffsetFactor = 0f,
                isTreasureChest = true,
                isChestClaimed = false
            )
        )

        return UnitData(
            unitNumber = 1,
            title = "الوحدة 1: الأساسيات والتحيات",
            description = "تعلم كيفية إلقاء التحية، تقديم نفسك، واستخدام الكلمات الأساسية بأدب.",
            colorHex = 0xFF58CC02, // Duolingo Green
            guideBookTips = listOf(
                "💡 التحية الصباحية 'Good morning' والمسائية 'Good evening'.",
                "☕ استخدم كلمات اللباقة مثل 'Please' و'Thank you' دائماً.",
                "🗣️ انتبه لنبرة الصوت عند طرح الأسئلة."
            ),
            lessons = lessons,
            isUnlocked = true,
            isCompleted = false
        )
    }

    private fun createUnit2(): UnitData {
        val stageMeta = listOf(
            Triple("قائمة الطعام والمطعم", "Menu, Waiter, Table", "🍽️"),
            Triple("طلب الأطباق الرئيسية", "Pasta, Rice, Chicken", "🍕"),
            Triple("الحساب والدفع", "Bill, Cash, Card", "💳"),
            Triple("الفواكه والخضار", "Apple, Banana, Salad", "🥗"),
            Triple("المذاق والتفضيل", "Delicious, Spicy, Sweet", "😋"),
            Triple("حجز طاولة مسبقاً", "Reservation for two", "📅"),
            Triple("المطبخ والمشروبات", "Juice, Milk, Soup", "🥤"),
            Triple("مفردات الأطعمة السريعة", "Burger, Fries, Snack", "🍔"),
            Triple("محادثة مع النادل", "Ordering conversation", "💬"),
            Triple("تحدي أطباق العالم", "Restaurant Master Exam", "🏆")
        )

        val lessons = createLockedLessons(2, stageMeta, "صندوق كنز الوحدة 2")
        return UnitData(
            unitNumber = 2,
            title = "الوحدة 2: في المطعم والمأكولات",
            description = "اطلب طعامك المفضل في المطعم، اسأل عن الحساب، وتحدث عن وجباتك اليومية.",
            colorHex = 0xFF1CB0F6, // Duolingo Blue
            guideBookTips = listOf(
                "🍽️ للسؤال عن الحساب: 'Can I have the bill, please?'.",
                "🍕 التعبير عن الإعجاب بالطعام: 'This is delicious!'."
            ),
            lessons = lessons,
            isUnlocked = false,
            isCompleted = false
        )
    }

    private fun createUnit3(): UnitData {
        val stageMeta = listOf(
            Triple("الاتجاهات في المدينة", "Turn left, Turn right", "🧭"),
            Triple("محطة القطار والحافلات", "Train station, Bus stop", "🚆"),
            Triple("وسائل النقل والمواصلات", "Taxi, Subway, Airport", "🚕"),
            Triple("الفندق وتسجيل الدخول", "Hotel, Check-in, Keys", "🏨"),
            Triple("السؤال عن المسافة", "How far is it?, Near, Far", "📍"),
            Triple("شراء التذاكر والرحلات", "Ticket, Single, Return", "🎫"),
            Triple("معالم المدينة الشهيرة", "Museum, Park, Bridge", "🏛️"),
            Triple("في المطار وجواز السفر", "Passport, Flight, Gate", "✈️"),
            Triple("طلب المساعدة في الطريق", "Excuse me, I'm lost", "🗺️"),
            Triple("اختبار خبير السفر", "Travel Explorer Exam", "🏆")
        )
        val lessons = createLockedLessons(3, stageMeta, "صندوق كنز الوحدة 3")
        return UnitData(
            unitNumber = 3,
            title = "الوحدة 3: الاتجاهات والسفر",
            description = "تنقل بثقة في شوارع المدينة ومحطات القطار والمطارات العالمية.",
            colorHex = 0xFFFF9600, // Duolingo Orange
            guideBookTips = listOf(
                "🧭 للاستفسار عن الاتجاه: 'Where is the nearest station?'.",
                "🚕 لتوجيه السائق: 'Please take me to this address'."
            ),
            lessons = lessons,
            isUnlocked = false,
            isCompleted = false
        )
    }

    private fun createUnit4(): UnitData {
        val stageMeta = listOf(
            Triple("الاستيقاظ والصباح", "Wake up, Brush teeth", "⏰"),
            Triple("الساعة والمواعيد", "What time is it?, O'clock", "⌚"),
            Triple("الأعمال والمهام المنزلية", "Clean, Cook, Laundry", "🧹"),
            Triple("أيام الأسبوع والشهور", "Monday, Friday, Weekend", "📆"),
            Triple("فترات اليوم والمساء", "Morning, Afternoon, Night", "🌙"),
            Triple("مواعيد النوم والراحة", "Go to bed, Sleep well", "🛏️"),
            Triple("الحديث عن العادات", "Always, Usually, Sometimes", "🔄"),
            Triple("التخطيط لليوم التالي", "Tomorrow's schedule", "📋"),
            Triple("محادثة تنظيم الوقت", "Time management talk", "🗣️"),
            Triple("امتحان روتين الحياة", "Daily Life Master Exam", "🏆")
        )
        val lessons = createLockedLessons(4, stageMeta, "صندوق كنز الوحدة 4")
        return UnitData(
            unitNumber = 4,
            title = "الوحدة 4: الروتين اليومي والوقت",
            description = "صف أنشطتك اليومية، حدد المواعيد، وتحدث عن عاداتك بطلاقة.",
            colorHex = 0xFFCE82FF, // Duolingo Purple
            guideBookTips = listOf(
                "⏰ للتعبير عن الوقت: 'It is half past eight'.",
                "🔄 استخدام ظروف التكرار: 'I always drink coffee in the morning'."
            ),
            lessons = lessons,
            isUnlocked = false,
            isCompleted = false
        )
    }

    private fun createUnit5(): UnitData {
        val stageMeta = listOf(
            Triple("أفراد العائلة الأقربين", "Father, Mother, Sister", "👨‍👩‍👧"),
            Triple("الأقارب والأجداد", "Grandpa, Grandma, Cousin", "👵"),
            Triple("المشاعر والأحاسيس", "Happy, Excited, Proud", "😊"),
            Triple("صفات الشخصية والطباع", "Kind, Smart, Funny", "🧠"),
            Triple("العلاقات والصداقة", "Best friend, Neighbors", "🤝"),
            Triple("الحديث عن المظهر", "Tall, Short, Dark hair", "👀"),
            Triple("الاحتفال والمناسبات", "Birthday, Party, Gift", "🎂"),
            Triple("التعبير عن الشوق", "I miss you, Visit soon", "💌"),
            Triple("حوار عائلي دافئ", "Family dinner talk", "💬"),
            Triple("امتحان الروابط العائلية", "Family & Emotions Exam", "🏆")
        )
        val lessons = createLockedLessons(5, stageMeta, "صندوق كنز الوحدة 5")
        return UnitData(
            unitNumber = 5,
            title = "الوحدة 5: العائلة والأصدقاء والمشاعر",
            description = "تحدث عن عائلتك، صف أصدقاءك، وعبر عن مشاعرك بصدق وسلاسة.",
            colorHex = 0xFFFF4B4B, // Duolingo Coral Red
            guideBookTips = listOf(
                "👨‍👩‍👧 لتقديم فرد من العائلة: 'This is my older brother'.",
                "😊 للتعبير عن المشاعر: 'I feel very excited today!'."
            ),
            lessons = lessons,
            isUnlocked = false,
            isCompleted = false
        )
    }

    private fun createUnit6(): UnitData {
        val stageMeta = listOf(
            Triple("المهن الشائعة", "Doctor, Teacher, Engineer", "💼"),
            Triple("في المكتب والعمل", "Office, Desk, Computer", "💻"),
            Triple("رسائل البريد والاتصال", "Email, Meeting, Phone call", "📧"),
            Triple("المهام والمشاريع", "Deadline, Project, Team", "📊"),
            Triple("مقابلة العمل الرسمية", "Interview, Experience, Resume", "👔"),
            Triple("بيئة العمل الإبداعية", "Design, Coding, Strategy", "🚀"),
            Triple("المفاوضات والاتفاقيات", "Contract, Deal, Partner", "📑"),
            Triple("إبداء الرأي في الاجتماع", "In my opinion, I agree", "💡"),
            Triple("حل مشكلات العمل", "Problem solving, Solution", "🛠️"),
            Triple("امتحان احتراف المهن", "Career Professional Exam", "🏆")
        )
        val lessons = createLockedLessons(6, stageMeta, "صندوق كنز الوحدة 6")
        return UnitData(
            unitNumber = 6,
            title = "الوحدة 6: العمل والمهن اليومية",
            description = "طور مصطلحاتك المهنية للتواصل في بيئة العمل والمقابلات والاجتماعات.",
            colorHex = 0xFF14B8A6, // Duolingo Teal
            guideBookTips = listOf(
                "💼 للتعبير عن مهنتك: 'I work as a software engineer'.",
                "📧 للبدء في رسالة رسمية: 'Dear Team, I hope this email finds you well'."
            ),
            lessons = lessons,
            isUnlocked = false,
            isCompleted = false
        )
    }

    private fun createUnit7(): UnitData {
        val stageMeta = listOf(
            Triple("في المركز التجاري", "Mall, Store, Shopping cart", "🛍️"),
            Triple("أنواع الملابس والأزياء", "Shirt, Pants, Jacket", "👕"),
            Triple("القياس والمقاس المناسب", "Size, Fit, Fitting room", "📏"),
            Triple("السؤال عن الأسعار", "How much is this?, Discount", "🏷️"),
            Triple("طرق الدفع والإرجاع", "Receipt, Return, Refund", "🧾"),
            Triple("الأحذية والإكسسوارات", "Shoes, Watch, Bag", "👟"),
            Triple("التسوق عبر الإنترنت", "Order, Shipping, Delivery", "📦"),
            Triple("المقارنة بين المنتجات", "Cheaper, Better, Quality", "⚖️"),
            Triple("المفاصلة والعروض", "Special offer, Bargain", "🎁"),
            Triple("امتحان خبير التسوق", "Smart Shopper Exam", "🏆")
        )
        val lessons = createLockedLessons(7, stageMeta, "صندوق كنز الوحدة 7")
        return UnitData(
            unitNumber = 7,
            title = "الوحدة 7: التسوق والأسعار والملابس",
            description = "اشترِ ما تحتاجه، اسأل عن المقاس والأسعار، واستفد من التخفيضات الذكية.",
            colorHex = 0xFFF59E0B, // Duolingo Amber
            guideBookTips = listOf(
                "🏷️ للسؤال عن السعر: 'How much does this cost?'.",
                "👕 لتجربة الملابس: 'Can I try this on in the fitting room?'."
            ),
            lessons = lessons,
            isUnlocked = false,
            isCompleted = false
        )
    }

    private fun createUnit8(): UnitData {
        val stageMeta = listOf(
            Triple("الرياضات المشهورة", "Football, Tennis, Running", "⚽"),
            Triple("الموسيقى والآلات", "Guitar, Piano, Song", "🎸"),
            Triple("القراءة والكتب", "Novel, Author, Reading", "📚"),
            Triple("الرسم والفنون", "Painting, Gallery, Art", "🎨"),
            Triple("السفر والتخييم", "Hiking, Campfire, Nature", "🏕️"),
            Triple("ألعاب الفيديو والذكاء", "Gaming, Chess, Puzzle", "🎮"),
            Triple("الحديث عما تحب فعله", "I enjoy, I love doing", "❤️"),
            Triple("دعوة صديق لنشاط", "Would you like to join me?", "🎟️"),
            Triple("نادي الهوايات والترفيه", "Club, Weekend activity", "🎪"),
            Triple("امتحان بطل الأنشطة", "Sports & Hobbies Exam", "🏆")
        )
        val lessons = createLockedLessons(8, stageMeta, "صندوق كنز الوحدة 8")
        return UnitData(
            unitNumber = 8,
            title = "الوحدة 8: الهوايات والرياضة والترفيه",
            description = "شارك شغفك وهواياتك وتحدث عن رياضتك المفضلة مع الآخرين.",
            colorHex = 0xFF6366F1, // Duolingo Indigo
            guideBookTips = listOf(
                "⚽ للحديث عما تفضله: 'I am passionate about playing football'.",
                "🎟️ لدعوة صديق: 'Do you want to play tennis this weekend?'."
            ),
            lessons = lessons,
            isUnlocked = false,
            isCompleted = false
        )
    }

    private fun createUnit9(): UnitData {
        val stageMeta = listOf(
            Triple("أعضاء الجسم البشري", "Head, Hand, Eye, Heart", "🫀"),
            Triple("في عيادة الطبيب", "Doctor, Clinic, Appointment", "🩺"),
            Triple("الأعراض والوعكات", "Headache, Fever, Cough", "🤒"),
            Triple("في الصيدلية والدواء", "Medicine, Pills, Prescription", "💊"),
            Triple("طلب الإسعاف والطوارئ", "Emergency, Call an ambulance", "🚑"),
            Triple("نصائح الصحة والغذاء", "Healthy diet, Vitamins", "🥑"),
            Triple("اللياقة والتمارين", "Gym, Workout, Hydration", "🏋️"),
            Triple("الاعتناء بالنفس والاستشفاء", "Rest, Recovery, Wellbeing", "🧘"),
            Triple("حوار استشارة الطبيب", "Doctor consultation talk", "📋"),
            Triple("امتحان الصحة والسلامة", "Health & Safety Exam", "🏆")
        )
        val lessons = createLockedLessons(9, stageMeta, "صندوق كنز الوحدة 9")
        return UnitData(
            unitNumber = 9,
            title = "الوحدة 9: الصحة والطوارئ والعيادة",
            description = "صف الأعراض بدقة، اطلب الدواء في الصيدلية، وتصرف في حالات الطوارئ.",
            colorHex = 0xFFF43F5E, // Duolingo Rose
            guideBookTips = listOf(
                "🩺 لوصف الألم: 'I have a sore throat and a mild headache'.",
                "🚑 في الطوارئ: 'Please help, this is an emergency!'."
            ),
            lessons = lessons,
            isUnlocked = false,
            isCompleted = false
        )
    }

    private fun createUnit10(): UnitData {
        val stageMeta = listOf(
            Triple("المناقشة وإبداء الرأي", "I believe that, Furthermore", "💬"),
            Triple("التعبير عن الافتراض", "If I were, Might have been", "🔮"),
            Triple("الأمثال والتعابير الاصطلاحية", "Piece of cake, Break a leg", "🎭"),
            Triple("سرد القصص والتجارب", "Once upon a time, Suddenly", "📖"),
            Triple("التفاوض والإقناع", "Persuasion, Common ground", "🤝"),
            Triple("الحديث عن المستقبل", "Predictions, Ambitions", "🚀"),
            Triple("الطلاقة في النطق السريع", "Natural rhythm & Intonation", "🎙️"),
            Triple("المناظرة والحوار الثقافي", "Cultural exchange, Diversity", "🌍"),
            Triple("المراجعة الشاملة لجميع الوحدات", "Grand Comprehensive Review", "👑"),
            Triple("امتحان التخرج الأسطوري", "Master of Fluency Exam", "🎓")
        )
        val lessons = createLockedLessons(10, stageMeta, "صندوق كنز التخرج الأسطوري")
        return UnitData(
            unitNumber = 10,
            title = "الوحدة 10: الطلاقة المتقدمة والامتحان الشامل",
            description = "توج مسيرتك التعليمية بالوصول إلى أعلى مستويات الطلاقة والمحادثة الحرة.",
            colorHex = 0xFFEAB308, // Duolingo Gold
            guideBookTips = listOf(
                "👑 استخدم التعبيرات الاصطلاحية لجعل لغتك تبدو كالمتحدث الأصلي.",
                "🎓 ركز على الربط المنطقي بين الأفكار لنقل رسالتك بقوة."
            ),
            lessons = lessons,
            isUnlocked = false,
            isCompleted = false
        )
    }

    private fun createLockedLessons(
        unitNumber: Int,
        metaList: List<Triple<String, String, String>>,
        chestTitle: String
    ): List<LessonNode> {
        val list = metaList.mapIndexed { index, meta ->
            val stageNum = index + 1
            LessonNode(
                id = "u${unitNumber}_l$stageNum",
                unitNumber = unitNumber,
                stageNumber = stageNum,
                title = meta.first,
                subtitle = meta.second,
                iconEmoji = meta.third,
                totalSteps = if (stageNum == 10) 8 else 5,
                completedSteps = 0,
                status = LessonNodeStatus.LOCKED,
                xOffsetFactor = stageXOffsets[index],
                isTreasureChest = false,
                isChestClaimed = false
            )
        }.toMutableList()

        // 11th stage: Treasure Chest
        list.add(
            LessonNode(
                id = "u${unitNumber}_chest",
                unitNumber = unitNumber,
                stageNumber = 11,
                title = chestTitle,
                subtitle = "100 XP + 25 جوهرة 💎",
                iconEmoji = "🎁",
                totalSteps = 1,
                completedSteps = 0,
                status = LessonNodeStatus.LOCKED,
                xOffsetFactor = 0f,
                isTreasureChest = true,
                isChestClaimed = false
            )
        )
        return list
    }
}
