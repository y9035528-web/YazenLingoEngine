package com.example.model

enum class QuestionType(val rawValue: String, val arabicLabel: String) {
    MULTIPLE_CHOICE("multiple_choice", "اختيار من متعدد"),
    WORD_ARRANGE("word_arrangement", "ترتيب الكلمات"),
    FILL_BLANK("fill_in_the_blank", "إكمال الفراغ"),
    LISTEN_SELECT("listen_and_select", "استماع واختيار")
}

data class ExerciseItem(
    val id: String,
    val type: QuestionType,
    val targetLanguage: String,
    val languageCode: String,
    val targetText: String,
    val phonetic: String,
    val instruction: String,
    val options: List<String>,
    val correctAnswer: String,
    val explanation: String,
    val xpReward: Int = 10,
    val sentenceWithBlank: String? = null
)

data class PointsBalance(
    val earnedXpThisStep: Int = 0,
    val totalXp: Int = 0,
    val gems: Int = 120,
    val heartsRemaining: Int = 5,
    val maxHearts: Int = 5,
    val streakDays: Int = 3
)

sealed interface StepSubmissionState {
    object Unanswered : StepSubmissionState
    data class Selected(val answer: String) : StepSubmissionState
    data class EvaluatedCorrect(
        val answer: String,
        val xpEarned: Int,
        val explanation: String
    ) : StepSubmissionState
    data class EvaluatedWrong(
        val answer: String,
        val correctAnswer: String,
        val explanation: String
    ) : StepSubmissionState
}

data class EngineStepResponse(
    val step: Int,
    val totalSteps: Int,
    val questionType: String,
    val targetLanguage: String,
    val targetText: String,
    val instruction: String,
    val options: List<String>,
    val correctAnswer: String,
    val userAnswer: String?,
    val isCorrect: Boolean?,
    val explanation: String?,
    val pointsBalance: PointsBalance
) {
    fun toJsonString(): String {
        val optionsJson = options.joinToString(separator = ",\n    ") { "\"${escapeJson(it)}\"" }
        val userAnswerStr = if (userAnswer != null) "\"${escapeJson(userAnswer)}\"" else "null"
        val isCorrectStr = if (isCorrect != null) "$isCorrect" else "null"
        val explanationStr = if (explanation != null) "\"${escapeJson(explanation)}\"" else "null"

        return """{
  "step": $step,
  "total_steps": $totalSteps,
  "question_type": "$questionType",
  "target_language": "$targetLanguage",
  "target_text": "${escapeJson(targetText)}",
  "instruction": "${escapeJson(instruction)}",
  "options": [
    $optionsJson
  ],
  "correct_answer": "${escapeJson(correctAnswer)}",
  "user_response": {
    "user_answer": $userAnswerStr,
    "is_correct": $isCorrectStr,
    "explanation": $explanationStr
  },
  "points_balance": {
    "earned_xp": ${pointsBalance.earnedXpThisStep},
    "total_xp": ${pointsBalance.totalXp},
    "hearts_remaining": ${pointsBalance.heartsRemaining},
    "max_hearts": ${pointsBalance.maxHearts},
    "streak_days": ${pointsBalance.streakDays}
  }
}""".trimIndent()
    }

    private fun escapeJson(input: String): String {
        return input
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }
}
