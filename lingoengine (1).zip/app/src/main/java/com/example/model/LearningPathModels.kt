package com.example.model

enum class LessonNodeStatus {
    COMPLETED,
    CURRENT,
    LOCKED
}

data class LessonNode(
    val id: String,
    val unitNumber: Int,
    val stageNumber: Int, // 1 to 10 for learning stages, 11 for the Treasure Chest
    val title: String,
    val subtitle: String,
    val iconEmoji: String,
    val totalSteps: Int,
    val completedSteps: Int,
    val status: LessonNodeStatus,
    val xOffsetFactor: Float, // -1f (left), 0f (center), 1f (right) for zig-zag
    val isTreasureChest: Boolean = false,
    val isChestClaimed: Boolean = false
)

data class UnitData(
    val unitNumber: Int,
    val title: String,
    val description: String,
    val colorHex: Long = 0xFF58CC02,
    val guideBookTips: List<String> = emptyList(),
    val lessons: List<LessonNode>,
    val isUnlocked: Boolean = (unitNumber == 1),
    val isCompleted: Boolean = false
)

enum class MainNavTab(val titleArabic: String) {
    LEARN("الدروس"),
    PRACTICE("المراجعة"),
    LEADERBOARD("الرتب"),
    PROFILE("الملف الشخصي")
}

/**
 * 5 Leagues / Tiers of Gamification progression based on XP.
 */
enum class LeagueTier(
    val id: String,
    val titleArabic: String,
    val badgeEmoji: String,
    val minXp: Int,
    val maxXp: Int,
    val colorHex: Long,
    val darkColorHex: Long,
    val description: String
) {
    BRONZE("bronze", "دوري البرونز", "🥉", 0, 150, 0xFFCD7F32, 0xFF78350F, "بداية التحدي وصقل المهارات الأساسية"),
    SILVER("silver", "دوري الفضة", "🥈", 151, 350, 0xFF94A3B8, 0xFF334155, "مستوى متقدم للمتعلمين المنتظمين"),
    GOLD("gold", "دوري الذهب", "🥇", 351, 700, 0xFFFFD700, 0xFFB45309, "نخبة المتفوقين والمنافسة القوية"),
    RUBY("ruby", "دوري الياقوت", "💎", 701, 1200, 0xFFF43F5E, 0xFF881337, "أقوى المنافسين وأصحاب الهمم العالية"),
    DIAMOND("diamond", "دوري الألماس", "👑", 1201, 99999, 0xFF38BDF8, 0xFF0369A1, "القمة المطلقة وأساطير Yazen lingo");

    companion object {
        fun fromXp(xp: Int): LeagueTier {
            return when {
                xp >= DIAMOND.minXp -> DIAMOND
                xp >= RUBY.minXp -> RUBY
                xp >= GOLD.minXp -> GOLD
                xp >= SILVER.minXp -> SILVER
                else -> BRONZE
            }
        }
    }
}

