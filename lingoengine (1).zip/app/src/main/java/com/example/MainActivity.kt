package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import com.example.model.MainNavTab
import com.example.sound.AudioFeedbackHelper
import com.example.ui.LingoUiState
import com.example.ui.LingoViewModel
import com.example.ui.components.CourseSelectorDialog
import com.example.ui.components.DuolingoBottomNavigation
import com.example.ui.components.ExerciseSessionScreen
import com.example.ui.components.GoogleAccountChooserDialog
import com.example.ui.components.HeartsDepletedDialog
import com.example.ui.components.JsonInspectorSheet
import com.example.ui.components.LeaderboardScreen
import com.example.ui.components.LeaguesScreen
import com.example.ui.components.LearningPathScreen
import com.example.ui.components.LessonCompletedScreen
import com.example.ui.components.LingoTopBar
import com.example.ui.components.PracticeScreen
import com.example.ui.components.ProfileScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: LingoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val context = LocalContext.current
            val audioHelper = remember { AudioFeedbackHelper(context) }

            DisposableEffect(audioHelper) {
                onDispose {
                    audioHelper.shutdown()
                }
            }

            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsState()

                LingoAppScreen(
                    uiState = uiState,
                    audioHelper = audioHelper,
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun LingoAppScreen(
    uiState: LingoUiState,
    audioHelper: AudioFeedbackHelper,
    viewModel: LingoViewModel
) {
    // 1. Check if Lesson is Finished
    if (uiState.isLessonCompleted) {
        LessonCompletedScreen(
            totalXp = uiState.pointsBalance.totalXp,
            heartsRemaining = uiState.pointsBalance.heartsRemaining,
            correctCount = uiState.correctCount,
            totalQuestions = uiState.currentCourse.exercises.size,
            onRestartLesson = { viewModel.exitLessonSession() },
            onSelectLanguage = { viewModel.toggleCourseSelector(true) },
            onOpenJsonInspector = { viewModel.toggleJsonInspector(true) }
        )
    }
    // 2. Check if user is actively in a quiz/exercise session
    else if (uiState.isInActiveExerciseSession) {
        ExerciseSessionScreen(
            uiState = uiState,
            audioHelper = audioHelper,
            viewModel = viewModel,
            onCloseSession = { viewModel.exitLessonSession() }
        )
    }
    // 3. Otherwise, show the full Duolingo hub with Top Bar, Main Navigation Tabs, and Bottom Bar
    else {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .testTag("lingo_hub_scaffold"),
            topBar = {
                LingoTopBar(
                    progress = 0f,
                    pointsBalance = uiState.pointsBalance,
                    courseTitle = uiState.currentCourse.titleArabic,
                    courseFlag = uiState.currentCourse.flagEmoji,
                    onLanguageClick = { viewModel.toggleCourseSelector(true) },
                    onOpenJsonInspector = { viewModel.toggleJsonInspector(true) },
                    showProgressBar = false
                )
            },
            bottomBar = {
                DuolingoBottomNavigation(
                    selectedTab = uiState.currentTab,
                    onTabSelected = { tab ->
                        viewModel.selectTab(tab)
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (uiState.currentTab) {
                    MainNavTab.LEARN -> {
                        LearningPathScreen(
                            units = uiState.units,
                            onSelectLesson = { lesson ->
                                viewModel.startLesson(lesson)
                            },
                            onClaimTreasureChest = { unitNum ->
                                viewModel.claimTreasureChest(unitNum)
                            }
                        )
                    }

                    MainNavTab.PRACTICE -> {
                        PracticeScreen(
                            onStartPracticeSession = {
                                viewModel.startLesson(null)
                            }
                        )
                    }

                    MainNavTab.LEADERBOARD -> {
                        LeaguesScreen(
                            currentXp = uiState.pointsBalance.totalXp,
                            userName = if (uiState.isGoogleSignedIn) uiState.userGoogleName else "أنت",
                            userAvatar = if (uiState.isGoogleSignedIn) "🧑‍🎓" else "🦉",
                            onPlayLessonToClimb = {
                                viewModel.selectTab(MainNavTab.LEARN)
                            }
                        )
                    }

                    MainNavTab.PROFILE -> {
                        ProfileScreen(
                            pointsBalance = uiState.pointsBalance,
                            courseTitle = uiState.currentCourse.titleArabic,
                            courseFlag = uiState.currentCourse.flagEmoji,
                            isGoogleSignedIn = uiState.isGoogleSignedIn,
                            userGoogleEmail = uiState.userGoogleEmail,
                            userGoogleName = uiState.userGoogleName,
                            onOpenGoogleAccountChooser = {
                                viewModel.openGoogleAccountChooser()
                            },
                            onSignOutGoogle = {
                                viewModel.signOutGoogle()
                            },
                            onRefillHearts = {
                                viewModel.refillHearts()
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet: Structured JSON Engine Inspector
    if (uiState.showJsonInspector) {
        JsonInspectorSheet(
            engineResponse = uiState.engineResponse,
            jsonString = uiState.jsonEngineOutput,
            onDismiss = { viewModel.toggleJsonInspector(false) }
        )
    }

    // Modal Dialog: Language Course Selector
    if (uiState.showCourseSelector) {
        CourseSelectorDialog(
            courses = uiState.courses,
            selectedCourse = uiState.currentCourse,
            onCourseSelected = { course ->
                viewModel.selectCourse(course)
            },
            onDismiss = { viewModel.toggleCourseSelector(false) }
        )
    }

    // Modal Dialog: Hearts Depleted
    if (uiState.showOutOfHeartsDialog) {
        HeartsDepletedDialog(
            onRefill = {
                viewModel.refillHearts()
            }
        )
    }

    // Modal Bottom Sheet: High-Contrast Google Account Chooser
    if (uiState.showGoogleAccountChooser) {
        GoogleAccountChooserDialog(
            currentSignedInEmail = uiState.userGoogleEmail,
            isCurrentlySignedIn = uiState.isGoogleSignedIn,
            onSelectAccount = { account ->
                viewModel.signInWithGoogleAccount(account)
                audioHelper.playSuccessFeedback()
            },
            onSignOut = {
                viewModel.signOutGoogle()
            },
            onDismiss = {
                viewModel.closeGoogleAccountChooser()
            }
        )
    }
}

